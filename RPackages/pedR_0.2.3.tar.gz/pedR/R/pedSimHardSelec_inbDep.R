#' A function to simulate selection, evolution, and population dyamics in a closed population
#'
#' This function runs a forward-time, genomic simulation of evolution (including mutation, selection, genetic drift, and migration effects). The simulation
#' saves the entire pedigree, genotypes at loci that affect fitness, and haplotype identities across the genome.
#' @param chrNum Number of simulated chromosomes. Must equal the length of chrLengs physLengs (see below). This will be overridden if a map file is provided.
#' @param chrLengs Vector of length chrNum giving the chromosome sizes in centiMorgans. Set to NULL if reading in a map file. This will be overridden if a map file is provided.
#' @param map A map file object to be used to assign physical chromosome sizes and the landscape of recombination rates across each chromosome.
#'     Genetic and physical chromsome lengths in the map file will override chrNum, chrLengs, and physLengs above when provided.
#' @param simLociNum The total number of locations on each chromosome to track throughout the simulation. For example, simLociNum = 100 means that the simulation will
#'     assign a unique identity to each of 2N (where N = the initial population size) copies of simLociNum nucleotide positions on each chromosome. A unique identity is also assigned
#'     to each copy of simLociNum loci on each chromosome for immigrants. The model then follows each of these chromosome segments through the simulated pedigree, thus allowing
#'     the user to quantify the total genomic contribution of each founder and immigrant in subsequent generations, and to estimate within- and between-individual genomic identity-by-descent.
#' @param gens Maximum number of generations to simulate. Note that the simulation model is of a random mating population (including self fertilization) with
#'     non-overlapping generations.
#' @param genoImport  A list of length 2, contining the first and second phased snp genotypes.
#' @param genoMap A map and fitness effects of loci segregating in the founders. This must be a matrix with three columns: first column: integers indicating which chromosome each locus is on.
#'     Second column: The position of each locus in centi-Morgans. Third column: the fitness effects of each snp (indicated as "neut" for neutral, "det" for detrimental, or "lethal" for loci with lethal effects)
#' @param carryCap Carrying capacity for the populations. Additional mortality will be imposed when the population exceeds carryCap.
#' @param popSize Defines the population size. If importing genotypes, popSize must be a vector indexing the individuals (rows) in the input genotype files
#      to be used as founder genomes (in this case, the length of popSize must be > 1). If not importing genotypes, then popSize must be a single number defining the population size in the founding generation.
#' @param famSize Mean number of offspring produced by a mother (Poisson distributed).
#' @param lambda The mean total fitness (lifetime reproductive success) of a mutation-free individual at very low population size.
#' @param immGenoImport List of length = 2, containing the first and second genomic copies of the immigrants. The immigrants will be used in order from the first to the last row. NULL if there is no immigration.
#' @param immGens  A vector of integers giving the generations to import immigrants. NULL if there is no immigration.
#' @param immNums A vector of immigrant numbers corresponding to each element in immGens. Must sum to <= the number of individuals represented in immGenoImport. Must be same length as immGens. NULL if there is no immigration.
#' @param immMap Map of genomic locations and fitness effects of SNPs segregating in the source population, using the same format as for genoMap described above. NULL if there is no immigration.
#' @param saveGenGenos Set to 1 to write genotype and haplotype identity files for each simulated generation in the current working directory. Set to NULL to keep only the genotypes and haplotype identities from the last simulated generation.
#' @details
#'
#'    Output:
#'
#'    pedObject is a data frame with one row for each individual and five columns including a unique indiviudal identifier (id); the ids
#'    of the two parents (mom and dad); the generation the individual was born in (gen); and whether the individual is an immigrant (0 = locally born,
#'    1 = immigrant).
#'
#'    orig1Mat and orig2Mat give the haplotype identities at each diploid copy of the genome for simLociNum*chrNum loci that are evenly spaced.
#'    The first column is the individual ID. The remaining columns give the haplotype identity of each position summarized in snpOrigMat (see below)
#'
#'    snpOrigMat gives the chromosome identity (column 1) and mapping positions (column 2) of tracked segments associated with orig1Mat and orig2Mat
#'
#'    geno1Mat and geno2Mat are matrices containing the diploid genotypes of the individuals left at the end of the simulation. The first column in each is the idividual ID.
#'    The remaining columns give the genotypes associated with the loci summarized in the rows of snpMat.
#'
#'    orig1Mat and orig2Mat are matrices containing the haplotype identities at simLociNum location in the genome. Each of simLociNum x chrNum chromosome segments is assigned 2N (where N is population size) unique
#'    identities in the first generation of the simulation. Each founder (and then each subsequent immigrant) carries two unique copies of each chromosomal segment. This makes it possible to track the genomic
#'    contribution of each founder and immigrant at the end of the simulation, and the genomic inbreeding (proportion of the genome with two identical-by-descent haplotypes) of any individual in the population.
#'    snpMat gives the chromosome (column 1), mapping position (column 2), and class ("det" for detrimental, "lethal" for loci carrying lethal alleles, column 3) of each
#'    SNP that is segregating at the end of the simulation.
#'
#'    BVec is a vector of the inbreeding load for each generation of the simulation.
#'
#'    LVec is a vector of the genetic load for each generation of the simulation.
#'
#'    NVec is a vector giving the population size for each simulated generation.
#'
#' @return
#'
#' @examples
#'
#'
#' @importFrom stats rbeta rexp rnorm rpois runif var lm
#' @importFrom utils read.table
#'
#' @export
#'
pedSimHardSelec_inbDep <- function(lethalU,detU,lethalDom,detrimental_s,detrimentalDom,chrNum,chrLengs,simLociNum,gens,genoImport,genoMap,carryCap,popSize,famSize,lambda,immGenoImport,immGens,immNums,immMap,saveGenGenos){
  physLengs <- chrLengs  # chromosome physical lengths are equal to the mapping length in cM
  if(is.null(chrLengs) == FALSE & is.null(physLengs) == FALSE & is.null(chrNum) == FALSE){
    if(3*chrNum != sum(chrNum,length(chrLengs),length(physLengs)))stop("lengths of chrLengs and physLengs must equal chrNum")
  }
  if(simLociNum <= 0)stop("must simulate at two segments for each chromosome")
  if(is.null(popSize) == TRUE) stop("must specify population size")
  if(sum(popSize < 1) > 0)stop("popSize must be a positive integer, or a vector of positive integers indexing which input genotypes to use)")
  if(is.null(genoImport) == FALSE){
    if(length(immGens) != length(immNums)) stop("length of immNums must equal length of immGens")
    if(sum(immNums) > nrow(immGenoImport[[1]]))  stop("number of immigrant genotypes must be >= the specified total number of immigrants")
  }

  options(scipen=999)

  ##################################
  # initialize the pedigree object
  ##################################
  if(length(popSize) > 1) imms <- 1:length(popSize)
  if(length(popSize) == 1) imms <- 1:popSize
  id <- 1:length(imms)
  mom <- rep(NA,length(id))
  dad <- rep(NA,length(id))
  gen <- rep(1,length(id))
  pedObject <- cbind(id,mom,dad,gen)    # store the simulated pedigree information

  ######################################
  # immigrant identities
  ######################################
  immVec <- rep(0,nrow(pedObject))   # indicator variable for immigrants
  immVec[imms] <- 1
  pedObject <- cbind(pedObject,immVec)

  ########################################
  # import founder genotypes if specified
  ########################################
  print("genotyping founding generation")
  if(is.null(genoImport) == FALSE) {
    snpMat <- genoMap
    chr1List <- list()     # list of chromosome data from the first chromosome copy
    chr2List <- list()     # list of chromosome data from the second chromosome copy
    for(i in 1:chrNum){
      theseGenos1 <- genoImport[[1]][popSize,(2:ncol(genoImport[[1]]))[which(snpMat[,1] == i)]]
      theseGenos2 <- genoImport[[2]][popSize,(2:ncol(genoImport[[2]]))[which(snpMat[,1] == i)]]
      chr1List [[i]] <- cbind(pedObject[,1],theseGenos1)  # save the polymorphic genotypes
      chr2List [[i]] <- cbind(pedObject[,1],theseGenos2)
    }

    chr1OrigList <- list()     # list of chromosome data from the first chromosome copy
    chr2OrigList <- list()     # list of chromosome data from the second chromosome copy
    origIter <- 1
    for(i in 1:chrNum){
      chr1OrigList [[i]] <- cbind(pedObject[,1],matrix(rep(origIter:(origIter + nrow(pedObject) - 1),simLociNum),nrow=nrow(pedObject),ncol=simLociNum))  # save the chromosome segment founder origins
      origIter <- origIter + (origIter + nrow(pedObject) - 1)
      chr2OrigList [[i]] <- cbind(pedObject[,1],matrix(rep(origIter:(origIter + nrow(pedObject) - 1),simLociNum),nrow=nrow(pedObject),ncol=simLociNum))#theseRealizedAFreqs <- colSums(rbind(chr1List[[i]][,2:ncol(chr1List[[i]])],chr2List[[i]][,2:ncol(chr2List[[i]])]) == "A")/(2*nrow(chr1List[[i]]))
      origIter <- 1
    }

    ################################################################################
    # keep track of the origin of simLociNum chromosome segements on each chromosome
    ################################################################################
    snpOrigChrs <- NULL
    snpOrigPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      snpOrigChrs <- c(snpOrigChrs,rep(i,simLociNum))
      theseSnpPos <- c(0.001,seq(physLengs[i]/(simLociNum-1),physLengs[i] - physLengs[i]/(simLociNum-1), physLengs[i]/(simLociNum-1)),physLengs[i]- 0.001)
      snpOrigPos <- c(snpOrigPos,theseSnpPos)
    }
    snpOrigMat <- cbind(snpOrigChrs,snpOrigPos)

    ##############################################################################################################
    # calculate the genetic load at equiibrium
    ##############################################################################################################
    # calculate genetic load at equillibrium
    L_lethal <-  1 - exp (-2*(lethalU))    # the lethal genetic load at selection/drift/mutation equilibrium
    L_det <-  1 - exp(-2*(detU))  # the detreimental genetic load at selection/drift/mutation equilibrium
    L_equil <- L_lethal + L_det   # total genetic load at equilibrium
    print(paste("genetic load (L) at equilibrium = ",round(L_equil,digits=2),sep=""))

    # calculate the inbreeding load at equilibrium
    K_det <- 1/(4*carryCap*detrimentalDom*detrimental_s + sqrt(2*pi*carryCap*detrimental_s) + 2)
    B_det <- (detrimental_s*detU*(1-2*detrimentalDom)) / ( (1/(2*carryCap)) + detrimentalDom*detrimental_s + detrimental_s*(1-detrimentalDom)*K_det)
    K_lethal <- 1/(4*carryCap*lethalDom + sqrt(2*pi*carryCap) + 2)
    B_lethal <- (lethalU*(1-2*lethalDom)) / ( (1/(2*carryCap)) + lethalDom + (1-lethalDom)*K_lethal)
    B_equil <- B_lethal + B_det
    print(paste("inbreeding load (B) at equilibrium (at carrying capacity) = ",round(B_equil,digits=2),sep=""))
  }


  ################################################
  # format immigrant genotypes
  ################################################
  if(is.null(immGenoImport) == FALSE){
    #### get rid of loci that are fixed wild type among the immigrants
    immACounts <- colSums(rbind(immGenoImport[[1]][,2:ncol(immGenoImport[[1]])],immGenoImport[[2]][,2:ncol(immGenoImport[[2]])])== "A")
    if(sum(immACounts == 0) > 0){
      immMap <- immMap[-which(immACounts == 0),]
      immGenoImport[[1]] <- immGenoImport[[1]][,-(which(immACounts == 0) + 1)]
      immGenoImport[[2]] <- immGenoImport[[2]][,-(which(immACounts == 0) + 1)]
    }

    # record the immigrant genotypes at loci with non-wild type alleles in the immigrants
    immChr1List <- list()
    immChr2List <- list()
    for(i in 1:chrNum){
      theseImmGenos1 <- immGenoImport[[1]][,(2:ncol(immGenoImport[[1]]))[which(immMap[,1] == i)]]
      theseImmGenos2 <- immGenoImport[[2]][,(2:ncol(immGenoImport[[2]]))[which(immMap[,1] == i)]]
      immChr1List [[i]] <- cbind(paste("imm_",1:nrow(immGenoImport[[1]]),sep=""),theseImmGenos1)  # save the polymorphic genotypes
      immChr2List [[i]] <- cbind(paste("imm_",1:nrow(immGenoImport[[1]]),sep=""),theseImmGenos2)
    }
  }

  #################################
  # some warnings
  #################################
  if(chrNum < length(unique(genoMap[,1])))stop("chrNum must be greater than or equal to the number of chromosomes in the imported genotype data")
  if(is.null(genoImport) == FALSE ) {
      if(length(imms) > nrow(genoImport[[1]])) stop("Number of imported genotpes must be greater than or equal to the population size in the first generation (popSize [1])")
  }

  ############################################################
  # initialize genotype matrices when not importing genotypes
  ############################################################
  if(is.null(genoImport)) {
    chr1List <- list()     # list of chromosome data from the first chromosome copy
    chr2List <- list()     # list of chromosome data from the second chromosome copy

    chr1OrigList <- list()     # list of chromosome data from the first chromosome copy
    chr2OrigList <- list()     # list of chromosome data from the second chromosome copy
    origIter <- 1
    for(i in 1:chrNum){
      #theseFreqs <- allFreqs[i,]
      theseGenos1 <- matrix("T",nrow=nrow(pedObject),ncol=2)
      theseGenos2 <- matrix("T",nrow=nrow(pedObject),ncol=2)
      chr1List [[i]] <- cbind(pedObject[,1],theseGenos1)  # save the polymorphic genotypes
      chr2List [[i]] <- cbind(pedObject[,1],theseGenos2)
      chr1OrigList [[i]] <- cbind(pedObject[,1],matrix(rep(origIter:(origIter + nrow(pedObject) - 1),simLociNum),nrow=nrow(pedObject),ncol=simLociNum))  # save the chromosome segment founder origins
      origIter <- origIter + (origIter + nrow(pedObject) - 1)
      chr2OrigList [[i]] <- cbind(pedObject[,1],matrix(rep(origIter:(origIter + nrow(pedObject) - 1),simLociNum),nrow=nrow(pedObject),ncol=simLociNum))#theseRealizedAFreqs <- colSums(rbind(chr1List[[i]][,2:ncol(chr1List[[i]])],chr2List[[i]][,2:ncol(chr2List[[i]])]) == "A")/(2*nrow(chr1List[[i]]))
      origIter <- 1
    }

    ##############################################################################################################
    # calculate the inbreeding load at equiibrium
    ##############################################################################################################
    # calculate the inbreeding load at equilibrium
    K_det <- 1/(4*carryCap*detrimentalDom*detrimental_s + sqrt(2*pi*carryCap*detrimental_s) + 2)
    B_det <- (detrimental_s*detU*(1-2*detrimentalDom)) / ( (1/(2*carryCap)) + detrimentalDom*detrimental_s + detrimental_s*(1-detrimentalDom)*K_det)
    K_lethal <- 1/(4*carryCap*lethalDom + sqrt(2*pi*carryCap) + 2)
    B_lethal <- (lethalU*(1-2*lethalDom)) / ( (1/(2*carryCap)) + lethalDom + (1-lethalDom)*K_lethal)
    B_equil <- B_lethal + B_det
    print(paste("inbreeding load (B) at equilibrium = ",round(B_equil,digits=2),sep=""))

    L_lethal <-  1 - exp (-2*(lethalU))    # the lethal genetic load at selection/drift/mutation equilibrium
    L_det <-  1 - exp(-2*(detU))  # the detreimental genetic load at selection/drift/mutation equilibrium
    L_equil <- L_lethal + L_det   # total genetic load at equilibrium
    print(paste("genetic load (L) at equilibrium = ",round(L_equil,digits=2),sep=""))


    snpChrs <- NULL
    snpPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      snpChrs <- c(snpChrs,rep(i,2))
      theseSnpPos <- c(0,physLengs[i])
      snpPos <- c(snpPos,theseSnpPos)
    }
    snpMat <- cbind(snpChrs,snpPos,rep("neut",length(snpPos)))                                               # object storing SNP chromosome assignments and positions

    ################################################################################
    # keep track of the origin of simLociNum chromosome segements on each chromosome
    ################################################################################
    snpOrigChrs <- NULL
    snpOrigPos <- NULL                                                                 # assign SNP positions on chromosomes
    for(i in 1:chrNum){
      snpOrigChrs <- c(snpOrigChrs,rep(i,simLociNum))
      theseSnpPos <- c(0.001,seq(physLengs[i]/(simLociNum-1),physLengs[i] - physLengs[i]/(simLociNum-1), physLengs[i]/(simLociNum-1)),physLengs[i]- 0.001)
      snpOrigPos <- c(snpOrigPos,theseSnpPos)
    }
    snpOrigMat <- cbind(snpOrigChrs,snpOrigPos)
  }

  ######################################
  # simulate 2:gens generations
  ######################################
  i <- 2            # iterate over generations
  extinct <- FALSE  # the population size is > 0 to start
  NVec <- nrow(pedObject)      # keep track of population size
  BVec <- NULL   # track the inbreeding load throught time
  LVec <- NULL
  detFreqList <- list()  # track detrimental allele frequencies
  lethalFreqList <- list()  # track lethal allele frequencies
  mutations <- NULL # keep track of the segregating mutations
  survVec <- NULL # keep track of who survives and who dies before adulthood
  inbVec <- NULL # record genomic inbreeding for each simulated individual
  outBredSurvProb <- (lambda)/(0.5*famSize)   # specify the survival probability of a mutation-free individual at very small population size
  immIterator <- 1       # iterator for grabbing immigrant genotypes
  immOrigIterator <- max(chr2OrigList[[1]][,2]) + 1

  while(i <= gens & extinct == FALSE){
    #####################################
    # immigration
    #####################################
    if(is.null(immGens) == FALSE){
      if(i %in% immGens){
        theseImmIds <- (max(pedObject[,1])+1):(max(pedObject[,1])+immNums[which(immGens == i)])

        # record the pedigree information for the immigrants
        immPedDat <- NULL
        for(y in 1:length(theseImmIds)){
          immPedDat <- rbind(immPedDat,c(theseImmIds[y],NA,NA,i-1,1))
        }
        pedObject <- rbind(pedObject,immPedDat)

        #----------------------------------------------------------
        # integrate the immigrant genotypes and mapping information
        #----------------------------------------------------------
        # integrate genotypes at loci that are segregating in the population but not in the immigrants into immigrant genomes
        immigrantGenos1 <- list()
        immigrantGenos2 <- list()
        outSnpMat <- NULL     #  snp information combining immigrant and resident segregating loci
        for(y in 1:chrNum){
          ####### add wildtype genotypes to immigrants at loci with segregating non-wildtype alleles only in the residents
          thisImmGeno1Mat <- immChr1List[[y]][immIterator:(immIterator + immNums[which(immGens == i)] - 1),2:ncol(immChr1List[[y]])]
          thisImmGeno2Mat <- immChr2List[[y]][immIterator:(immIterator + immNums[which(immGens == i)] - 1),2:ncol(immChr2List[[y]])]
          theseImmPos <- immMap[which(immMap[,1] == y),]     # positions of loci where there are non-wildtype alleles among the immigrants
          theseResPos <- snpMat[which(snpMat[,1] == y & (snpMat[,2] %in% theseImmPos[,2] == FALSE)),]   # positions of loci segregating in residents but not in the immigrants
          addNum <- sum(theseResPos[,2] %in% theseImmPos[,2] == FALSE)
          thisPosMat <- rbind(theseImmPos,theseResPos)
          if(length(theseImmIds) == 1){
            thisImmGeno1Mat <- c(thisImmGeno1Mat,rep("T",addNum))
            thisImmGeno1Mat <- thisImmGeno1Mat[order(as.numeric(thisPosMat[,2]))]
            thisImmGeno2Mat <- c(thisImmGeno2Mat,rep("T",addNum))
            thisImmGeno2Mat <- thisImmGeno2Mat[order(as.numeric(thisPosMat[,2]))]
          }
          if(length(theseImmIds) > 1){
            thisImmGeno1Mat <- cbind(thisImmGeno1Mat,matrix("T",nrow=length(theseImmIds),ncol=addNum))
            thisimmGeno1Mat <- thisImmGeno1Mat[,order(as.numeric(thisPosMat[,2]))]
            thisImmGeno2Mat <- cbind(thisImmGeno2Mat,matrix("T",nrow=length(theseImmIds),ncol=addNum))
            thisImmGeno2Mat <- thisImmGeno2Mat[,order(as.numeric(thisPosMat[,2]))]
          }

          ##### add wildtype genotypes to residents at loci with segregating non-wildtype alleles only in the immigrants
          resIDs <- chr1List[[y]][,1]  # retain the resident identities
          thisResGeno1Mat <- chr1List[[y]][,2:ncol(chr1List[[y]])]
          thisResGeno2Mat <- chr2List[[y]][,2:ncol(chr2List[[y]])]
          theseImmPos <- immMap[which(immMap[,1] == y & (immMap[,2] %in% snpMat[,2] == FALSE)),]     # positions of loci segregating in the immigrants but not in the residents
          theseResPos <- snpMat[which(snpMat[,1] == y),]   # positions of loci already segregating in the residents
          addNum <- sum(theseImmPos[,2] %in% theseResPos[,2] == FALSE)
          thisPosMat <- rbind(theseResPos,theseImmPos)
          if(length(resIDs) == 1){
            thisResGeno1Mat <- c(thisResGeno1Mat,rep("T",addNum))
            thisResGeno1Mat <- thisResGeno1Mat[order(as.numeric(thisPosMat[,2]))]
            thisResGeno2Mat <- c(thisResGeno2Mat,rep("T",addNum))
            thisResGeno2Mat <- thisResGeno2Mat[order(as.numeric(thisPosMat[,2]))]
          }
          if(length(resIDs) > 1){
            thisResGeno1Mat <- cbind(thisResGeno1Mat,matrix("T",nrow=length(resIDs),ncol=addNum))
            thisResGeno1Mat <- thisResGeno1Mat[,order(as.numeric(thisPosMat[,2]))]
            thisResGeno2Mat <- cbind(thisResGeno2Mat,matrix("T",nrow=length(resIDs),ncol=addNum))
            thisResGeno2Mat <- thisResGeno2Mat[,order(as.numeric(thisPosMat[,2]))]
          }

          chr1List[[y]] <- cbind(c(resIDs,theseImmIds),rbind(thisResGeno1Mat,thisImmGeno1Mat))
          chr2List[[y]] <- cbind(c(resIDs,theseImmIds),rbind(thisResGeno2Mat,thisImmGeno2Mat))

          thisPosMat <- thisPosMat[order(as.numeric(thisPosMat[,2])),]
          outSnpMat <- rbind(outSnpMat,thisPosMat)
        }
        immIterator <- immIterator + immNums[which(immGens == i)]
        snpMat <- outSnpMat

        ####################################################
        # add haplotype identities for the immigrants
        ####################################################
        for(y in 1:length(theseImmIds)){
          outOrigVec1 <- c(theseImmIds[y],rep(immOrigIterator,simLociNum))
          outOrigVec2 <- c(theseImmIds[y],rep(immOrigIterator+1,simLociNum))
          for(z in 1:chrNum){
            chr1OrigList[[z]] <- rbind(chr1OrigList[[z]],outOrigVec1)
            chr2OrigList[[z]] <- rbind(chr2OrigList[[z]],outOrigVec2)
          }
          immOrigIterator <- immOrigIterator + 2
        }

        #survTest <- c(survTest,rep(1,length(theseImmIds)))   # immigrants arrive as adults, so indicate that they survived to adulthood
        #inbVec <- c(inbVec,rep(0,length(theseImmIds)))
      }
    }




    aCntMat <- NULL        # get allele frequencies
    for(j in 1:chrNum){
      theseAFreqs <- colSums(rbind(chr1List[[j]][,2:ncol(chr1List[[j]])],chr2List[[j]][,2:ncol(chr2List[[j]])]) == "A")/(2*nrow(chr1List[[j]]))
      aCntMat <- rbind(aCntMat,cbind(rep(j,length(theseAFreqs)),1:length(theseAFreqs),theseAFreqs))
    }

    ##### calculate and record idividual inbreeding
    thisIBDVec <- rep(0,nrow(chr1OrigList[[1]]))   # number of IBD chromosome segments for each individual
    for(y in 1:chrNum){
      thisIBDVec <- thisIBDVec + rowSums(chr1OrigList[[y]][,2:ncol(chr1OrigList[[y]])] == chr2OrigList[[y]][,2:ncol(chr2OrigList[[y]])])
    }
    inbVec <- c(inbVec,thisIBDVec/(simLociNum*chrNum))

    ##### calculate and record the standing inbreeding and genetic loads
    detMuts <- sum(snpMat[,3] == "det")   # number of detrimental loci
    lethalMuts <- sum(snpMat[,3] == "lethal")  # number of lethal loci
    if(lethalMuts > 0){
      lethalGenos1 <- NULL
      lethalGenos2 <- NULL
      for(y in 1:chrNum){
        if(sum(snpMat[,1] == y) > 0 & sum(snpMat[,3] == "lethal") > 0){
          theseSnps <- snpMat[which(snpMat[,1] == y),]
          lethalGenos1 <- cbind(lethalGenos1,chr1List[[y]][,which(theseSnps[,3] == "lethal")+1])
          lethalGenos2 <- cbind(lethalGenos2,chr2List[[y]][,which(theseSnps[,3] == "lethal")+1])
        }
      }
      lethalFreqs <- colSums(rbind(lethalGenos1,lethalGenos2) == "A")/(2*nrow(lethalGenos1))
      lethalFreqList [[i]] <- lethalFreqs
      thisLethalB <- log ((outBredSurvProb*prod(1-2*lethalFreqs*(1-lethalFreqs)*lethalDom - (lethalFreqs^2)) ) /
                            (outBredSurvProb*prod(1-2*lethalFreqs*(1-lethalFreqs)*lethalDom - (lethalFreqs^2) - lethalFreqs*(1-lethalFreqs)*(1-2*lethalDom))))

      lethalCounts <- (lethalGenos1 == "A") + (lethalGenos2 == "A")
      #get the fitness at each selected locus for each individual
      lethalFits <- matrix(NA,nrow=nrow(lethalGenos1),ncol=ncol(lethalCounts))
      for(j in 1:ncol(lethalCounts)){
        if(sum(lethalCounts[,j] == 0) > 0)lethalFits[which(lethalCounts[,j] == 0),j] <- 1
        if(sum(lethalCounts[,j] == 1) > 0)lethalFits[which(lethalCounts[,j] == 1),j] <- 1 - lethalDom
        if(sum(lethalCounts[,j] == 2) > 0)lethalFits[which(lethalCounts[,j] == 2),j] <- 0
      }
    }

    if(detMuts > 0){
      detGenos1 <- NULL
      detGenos2 <- NULL
      for(y in 1:chrNum){
        if(sum(snpMat[,1] == y) > 0 & sum(snpMat[,3] == "det") > 0){
          theseSnps <- snpMat[which(snpMat[,1] == y),]
          detGenos1 <- cbind(detGenos1,chr1List[[y]][,which(theseSnps[,3] == "det")+1])
          detGenos2 <- cbind(detGenos2,chr2List[[y]][,which(theseSnps[,3] == "det")+1])
        }
      }
      detFreqs <- colSums(rbind(detGenos1,detGenos2) == "A")/(2*nrow(detGenos1))
      detFreqList [[i]] <- detFreqs

      thisDetrimentalB <- log ((outBredSurvProb*prod(1-2*detFreqs*(1-detFreqs)*detrimental_s*detrimentalDom - (detFreqs^2)*detrimental_s ) ) /
                                 (outBredSurvProb*prod(1-2*detFreqs*(1-detFreqs)*detrimental_s*detrimentalDom - (detFreqs^2)*detrimental_s - detFreqs*(1-detFreqs)*detrimental_s*(1-2*detrimentalDom))))

      detCounts <- (detGenos1 == "A") + (detGenos2 == "A")
      detFits <- matrix(NA,nrow=nrow(detCounts),ncol=ncol(detCounts))
      for(j in 1:ncol(detCounts)){
        if(sum(detCounts[,j] == 0) > 0)detFits[which(detCounts[,j] == 0),j] <- 1
        if(sum(detCounts[,j] == 1) > 0)detFits[which(detCounts[,j] == 1),j] <- 1 - detrimentalDom*detrimental_s
        if(sum(detCounts[,j] == 2) > 0)detFits[which(detCounts[,j] == 2),j] <- 1-detrimental_s
      }
    }
    if(lethalMuts > 0 & detMuts > 0) survProbMult<- matrixStats::rowProds(cbind(lethalFits,detFits))
    if(lethalMuts > 0 & detMuts == 0) survProbMult <- matrixStats::rowProds(lethalFits)
    if(lethalMuts == 0 & detMuts > 0) survProbMult<- matrixStats::rowProds(detFits)
    if(lethalMuts == 0 & detMuts == 0) survProbMult <- rep(1,nrow(chr1List[[1]]))
    if(lethalMuts == 0) thisLethalB <- 0            # calculate the standing inbreeding load
    if(detMuts == 0) thisDetrimentalB <- 0
    survProbs <- rep(NA,length(survProbMult))
    if(sum(survProbMult == 0) > 0)survProbs[which(survProbMult == 0)] <- 0

    BVec <- c(BVec,thisLethalB+thisDetrimentalB)
    intFit <- 0.5*survProbMult*outBredSurvProb*famSize                          # intrinsic individual fitness
    outBredFit <- 0.5*outBredSurvProb*famSize
    meanFit <- mean(intFit)                                                     # mean intrinsic fitness

    mutFreeFit <- lambda - (lambda - 1)*(length(intFit)/carryCap)               # what would mean fitness be for mutation-free individuals at the current population size?
    if(meanFit >= 1){
      expSize <- length(intFit)*exp(log(meanFit)*(1-(length(intFit)/carryCap)))   # expected number of offspring given carrying capacity and logistic population growth growth
    }
    if(meanFit < 1){
      expSize <- meanFit * length(intFit)   # expected number of offspring given carrying capacity and logistic population growth growth
    }
    print(paste("mean expected fitness = ", expSize/length(intFit),sep=""))

    needSurvProb <- (expSize/length(intFit))/(0.5*famSize)                      # mean survival probability to get to expSize offspring on average
    if(sum(survProbMult) > 0){
      survProbs <- survProbMult * (needSurvProb/mean(survProbMult))               # scale the survival probabilityes to account for density dependent population growth
      survTest <- runif(length(survProbs),0,1) <= survProbs                       # use a random number generator to test for survival
      survVec <- c(survVec,survTest)                                              # record individual survival
      removeInds <- which(survTest == 0)
    }
    LVec <- c(LVec,(outBredFit - (mean(intFit)))/outBredFit)    # record the genetic load
                                          # which individuals need to be removed from the population
    if(sum(survProbMult) == 0){
      survTest <- rep(0,length(survProbMult))
      survVec <- c(survVec,survTest)
    }
    ##########################
    # check for extinction
    ##########################
    if(sum(survTest == 1) <= 1) {
      extinct <- TRUE
    }
    if(sum(survTest) > 1){ # continue if there are at least two parents remaining
      remainInds <- (1:length(intFit))[which(1:length(intFit) %in% removeInds == FALSE)]
      moms <- sample(x=pedObject[which(pedObject[,4] == i - 1)[remainInds],1],size=round(0.5*length(remainInds)),replace=TRUE)   # sample moms with selection
      dads <- rep(NA,length(moms))
      for(z in 1:length(moms)){
        possibleDads <- pedObject[which(pedObject[,4] == i - 1)[remainInds],1][-which(pedObject[which(pedObject[,4] == i - 1)[remainInds],1] == moms[z])]
        if(length(possibleDads) > 1)dads[z] <- sample(x=possibleDads,size=1,replace=FALSE)
        if(length(possibleDads) == 1)dads[z] <- possibleDads
      }
    }

    # assign family sizes
    nOffs <- 0 # initialize nOffs at zero
    if(length(moms) > 0){        # assign family sizes if there are any mother-father pairs
      nOffs <- rpois(n=length(moms),lambda = famSize)
    }
    if(length(moms) == 0 | sum(nOffs) <= 1 | sum(is.na(dads)) == length(dads)){        # check for family sizes sith size > 0
      extinct <- TRUE
    }

    ###################################################
    # assign IDs for new offspring (if there are any)
    ###################################################
    if(extinct == FALSE){
      ##############################################################
      # remove loci with no deleterious variation among the parents
      ##############################################################
      for(y in 1:chrNum){
        if(ncol(chr1List[[y]]) > 3){
          parACounts <- colSums(chr1List[[y]][which(chr1List[[y]][,1] %in% c(moms,dads)),3:(ncol(chr1List[[y]])-1)] == "A") + colSums(chr2List[[y]][which(chr2List[[y]][,1] %in% c(moms,dads)),3:(ncol(chr2List[[y]])-1)] == "A")
          #### remove loci fixed for the wild type allele in the parents
          chr1List[[y]] <- chr1List[[y]][,c(1,2,which(parACounts > 0) + 2,ncol(chr1List[[y]]))]
          chr2List[[y]] <- chr2List[[y]][,c(1,2,which(parACounts > 0) + 2,ncol(chr2List[[y]]))]
          thisSnpMat <- snpMat[which(snpMat[,1] == y),]
          thisSnpMat <- thisSnpMat[c(1,which(parACounts > 0) + 1,nrow(thisSnpMat)),]
          snpMat <- snpMat[-which(snpMat[,1] == y),]

          if(sum(snpMat[,1] < thisSnpMat[1,1]) == 0   & sum(snpMat[,1] > thisSnpMat[1,1]) > 0) snpMat <- rbind(thisSnpMat,snpMat[which(snpMat[,1] > thisSnpMat[1,1]),])
          if(sum(snpMat[,1] < thisSnpMat[1,1]) > 0   & sum(snpMat[,1] > thisSnpMat[1,1]) > 0) snpMat <- rbind(snpMat[which(snpMat[,1] < thisSnpMat[1,1]),],thisSnpMat,snpMat[which(snpMat[,1] > thisSnpMat[1,1]),])
          if(sum(snpMat[,1] < thisSnpMat[1,1]) > 0   & sum(snpMat[,1] > thisSnpMat[1,1]) == 0) snpMat <- rbind(snpMat[which(snpMat[,1] < thisSnpMat[1,1]),],thisSnpMat)
        }
      }
      theseInds <- (nrow(pedObject)+1):(nrow(pedObject)+ sum(nOffs))  # vector of non-immgrant individuals to assign haplotypes to
      id <-  (max(pedObject[,1])+1):(max(pedObject[,1])+length(theseInds))
      NVec <- c(NVec,length(id))
      gen <- rep(i, length(id))
      immVec <- rep(0,length(id))
      mom <- NULL
      dad <- NULL
      for(z in 1:length(moms)){
        mom <- c(mom,rep(moms[z],nOffs[z]))
        dad <- c(dad,rep(dads[z],nOffs[z]))
      }
      parentPairs <- cbind(mom,dad)
      outDat <- cbind(id,mom,dad,gen,immVec)
      pedObject <- rbind(pedObject,outDat)

      #####################################################
      # Mutation and Mendelian segregation
      #####################################################
      offChr1 <- list()
      offChr2 <- list()
      offChr1Orig <- list()
      offChr2Orig <- list()

      for(k in 1:chrNum){
        snpLocs <- as.numeric(snpMat[which(snpMat[,1] == k),2])
        snpOrigLocs <- snpOrigMat[which(snpOrigMat[,1] == k),2]
        if(nrow(parentPairs) > 1){
          momsCopy1 <- chr1List[[k]][match(parentPairs[,1],chr1List[[k]][,1]),]
          dadsCopy1 <- chr1List[[k]][match(parentPairs[,2],chr1List[[k]][,1]),]
          momsCopy2 <- chr2List[[k]][match(parentPairs[,1],chr2List[[k]][,1]),]
          dadsCopy2 <- chr2List[[k]][match(parentPairs[,2],chr2List[[k]][,1]),]
        }
        if(nrow(parentPairs) == 1){
          momsCopy1 <- NULL
          momsCopy2 <- NULL
          dadsCopy1 <- NULL
          dadsCopy2 <- NULL
          momsCopy1 <- chr1List[[k]][match(parentPairs[,1],chr1List[[k]][,1]),]
          dadsCopy1 <- chr1List[[k]][match(parentPairs[,2],chr1List[[k]][,1]),]
          momsCopy2 <- chr2List[[k]][match(parentPairs[,1],chr2List[[k]][,1]),]
          dadsCopy2 <- chr2List[[k]][match(parentPairs[,2],chr2List[[k]][,1]),]
        }

        ##### chromosome segement origins
        if(nrow(parentPairs) > 1){
          momsOrigCopy1 <- chr1OrigList[[k]][match(parentPairs[,1],chr1OrigList[[k]][,1]),]
          dadsOrigCopy1 <- chr1OrigList[[k]][match(parentPairs[,2],chr1OrigList[[k]][,1]),]
          momsOrigCopy2 <- chr2OrigList[[k]][match(parentPairs[,1],chr2OrigList[[k]][,1]),]
          dadsOrigCopy2 <- chr2OrigList[[k]][match(parentPairs[,2],chr2OrigList[[k]][,1]),]
        }
        if(nrow(parentPairs) == 1){
          momsOrigCopy1 <- NULL
          momsOrigCopy2 <- NULL
          dadsOrigCopy1 <- NULL
          dadsOrigCopy2 <- NULL
          momsOrigCopy1 <- chr1OrigList[[k]][match(parentPairs[,1],chr1OrigList[[k]][,1]),]
          dadsOrigCopy1 <- chr1OrigList[[k]][match(parentPairs[,2],chr1OrigList[[k]][,1]),]
          momsOrigCopy2 <- chr2OrigList[[k]][match(parentPairs[,1],chr2OrigList[[k]][,1]),]
          dadsOrigCopy2 <- chr2OrigList[[k]][match(parentPairs[,2],chr2OrigList[[k]][,1]),]
        }

        #--------------------------------------------
        # maternal Meiosis
        #--------------------------------------------
        momRecs <- rpois(n=length(id),lambda=chrLengs[k]/100)    # number of recombination events in the mom
        momRecLocsMat <- matrix(NA,nrow=length(id),ncol=max(momRecs)+1)
        for(z in 1:ncol(momRecLocsMat)){   # draw locations of crossovers for all individuals
          momRecLocsMat[which(momRecs >= z),z] <- runif(n=length(which(momRecs >= z)),min=0,max=chrLengs[k])
          if(sum(momRecs == (z-1)) > 0) momRecLocsMat[which(momRecs == (z-1)),z] <- chrLengs[k]
        }
        if(sum(momRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(momRecs > 1)
          for(b in moreThanOneRec){
            momRecLocsMat[b,1:(momRecs[b]+1)] <- sort(momRecLocsMat[b,])
          }
        }
        momChrPicker <- sample(x=c(1,2),size=length(id),replace=TRUE) # which parental chromosome copy to sample first
        offMomGenos <- matrix(NA,nrow=length(id),ncol=ncol(chr1List[[k]])-1)        #  initialize offspring genotype matrix
        offMomGenosOrig <- matrix(NA,nrow=length(id),ncol=simLociNum)    #  initialize offspring genotype matrix
        for(b in 1:(max(momRecs)+1)){        # assign genotypes to offspring
          thisMomGenoMat <- matrix(NA,nrow=length(id),ncol=ncol(offMomGenos))    # gather the relevant chromosome copies from the mother
          thisMomGenoMatOrig <- matrix(NA,nrow=length(id),ncol=ncol(offMomGenosOrig))
          if(sum(momChrPicker == 1) > 0){
            thisMomGenoMat[which(momChrPicker == 1),] <- momsCopy1[which(momChrPicker == 1),2:ncol(momsCopy1)]
            thisMomGenoMatOrig[which(momChrPicker == 1),] <- momsOrigCopy1[which(momChrPicker == 1),2:ncol(momsOrigCopy1)]
          }
          if(sum(momChrPicker == 2) > 0){
            thisMomGenoMat[which(momChrPicker == 2),] <- momsCopy2[which(momChrPicker == 2),2:ncol(momsCopy2)]
            thisMomGenoMatOrig[which(momChrPicker == 2),] <- momsOrigCopy2[which(momChrPicker == 2),2:ncol(momsOrigCopy2)]
          }
          if(b == 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p]),p]
            }
            for(p in 1:ncol(offMomGenosOrig)){
              if(sum(momRecLocsMat[,b] >= snpOrigLocs[p],na.rm=TRUE) > 0) offMomGenosOrig[which(momRecLocsMat[,b] >= snpOrigLocs[p]),p] <- thisMomGenoMatOrig[which(momRecLocsMat[,b] >= snpOrigLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offMomGenos)){
              if(sum(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenos[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMat[which(momRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > momRecLocsMat[,b-1]),p]
            }
            for(p in 1:ncol(offMomGenosOrig)){
              if(sum(momRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > momRecLocsMat[,b-1],na.rm=TRUE) > 0) offMomGenosOrig[which(momRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > momRecLocsMat[,b-1]),p] <- thisMomGenoMatOrig[which(momRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > momRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(momChrPicker))
          if(sum(momChrPicker == 1) > 0) newChrPicker[which(momChrPicker == 1)] <- 2
          momChrPicker <- newChrPicker
        }
        offChromOnes <- cbind(id,offMomGenos)
        offChromOnesOrig <- cbind(id,offMomGenosOrig)

        #--------------------------------------------
        # paternal Meiosis
        #--------------------------------------------
        dadRecs <- rpois(n=length(id),lambda=chrLengs[k]/100)    # number of recombination events in the dad
        dadRecLocsMat <- matrix(NA,nrow=length(id),ncol=max(dadRecs)+1)
        for(z in 1:ncol(dadRecLocsMat)){   # draw locations of crossovers for all individuals
          dadRecLocsMat[which(dadRecs >= z),z] <- runif(n=length(which(dadRecs >= z)),min=0,max=chrLengs[k])
          if(sum(dadRecs == (z-1)) > 0) dadRecLocsMat[which(dadRecs == (z-1)),z] <- chrLengs[k]
        }
        if(sum(dadRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(dadRecs > 1)
          for(b in moreThanOneRec){
            dadRecLocsMat[b,1:(dadRecs[b]+1)] <- sort(dadRecLocsMat[b,])
          }
        }
        dadChrPicker <- sample(x=c(1,2),size=length(id),replace=TRUE) # which parental chromosome copy to sample first
        offDadGenos <- matrix(NA,nrow=length(id),ncol=ncol(chr1List[[k]])-1)        #  initialize offspring genotype matrix
        offDadGenosOrig <- matrix(NA,nrow=length(id),ncol=simLociNum)    #  initialize offspring genotype matrix
        for(b in 1:(max(dadRecs)+1)){        # assign genotypes to offspring
          thisDadGenoMat <- matrix(NA,nrow=length(id),ncol=ncol(offDadGenos))
          thisDadGenoMatOrig <- matrix(NA,nrow=length(id),ncol=ncol(offDadGenosOrig))
          if(sum(dadChrPicker == 1) > 0){
            thisDadGenoMat[which(dadChrPicker == 1),] <- dadsCopy1[which(dadChrPicker == 1),2:ncol(dadsCopy1)]
            thisDadGenoMatOrig[which(dadChrPicker == 1),] <- dadsOrigCopy1[which(dadChrPicker == 1),2:ncol(dadsOrigCopy1)]
          }
          if(sum(dadChrPicker == 2) > 0){
            thisDadGenoMat[which(dadChrPicker == 2),] <- dadsCopy2[which(dadChrPicker == 2),2:ncol(dadsCopy2)]
            thisDadGenoMatOrig[which(dadChrPicker == 2),] <- dadsOrigCopy2[which(dadChrPicker == 2),2:ncol(dadsOrigCopy2)]
          }
          if(b == 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p]),p]
            }
            for(p in 1:ncol(offDadGenosOrig)){
              if(sum(dadRecLocsMat[,b] >= snpOrigLocs[p],na.rm=TRUE) > 0) offDadGenosOrig[which(dadRecLocsMat[,b] >= snpOrigLocs[p]),p] <- thisDadGenoMatOrig[which(dadRecLocsMat[,b] >= snpOrigLocs[p]),p]
            }
          }
          if(b > 1){
            for(p in 1:ncol(offDadGenos)){
              if(sum(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenos[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMat[which(dadRecLocsMat[,b] >= snpLocs[p] & snpLocs[p] > dadRecLocsMat[,b-1]),p]
            }
            for(p in 1:ncol(offDadGenosOrig)){
              if(sum(dadRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > dadRecLocsMat[,b-1],na.rm=TRUE) > 0) offDadGenosOrig[which(dadRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > dadRecLocsMat[,b-1]),p] <- thisDadGenoMatOrig[which(dadRecLocsMat[,b] >= snpOrigLocs[p] & snpOrigLocs[p] > dadRecLocsMat[,b-1]),p]
            }
          }
          #### iterate the chrPicker
          newChrPicker <- rep(1,length(dadChrPicker))
          if(sum(dadChrPicker == 1) > 0) newChrPicker[which(dadChrPicker == 1)] <- 2
          dadChrPicker <- newChrPicker
        }
        offChromTwos <- cbind(id,offDadGenos)
        offChromTwosOrig <- cbind(id,offDadGenosOrig)
        offChr1[[k]] <- offChromOnes
        offChr2[[k]] <- offChromTwos
        offChr1Orig[[k]] <- offChromOnesOrig
        offChr2Orig[[k]] <- offChromTwosOrig
      }

      ##############################################################
      # mutation
      ##############################################################
      # define the number of lethal and detrimental mutations
      numLethMuts <- rpois(1,lambda = 2*lethalU*nrow(offChr1[[1]]))
      numDetMuts <- rpois(1,lambda = 2*detU*nrow(offChr1[[1]]))
      outChr1List <- list()    # store genotypes after mutation
      outChr2List <- list()
      outMutInfo <- NULL # record the information on new mutations


      ########## nearly recessive lethal mutations
      if(numLethMuts > 0){
        thisOutMutInfo <- NULL # keep track of lethal mutations
        lethMutLocs <- runif(numLethMuts,min=0,max=chrLengs[1])
        lethMutChroms <- sample(1:chrNum,numLethMuts,replace=TRUE)
        lethMutChrCopy <- sample(1:2,size=numLethMuts,replace=TRUE)
        lethMutInds <- sample(1:nrow(offChr1[[1]]),numLethMuts,replace=TRUE)
        uniqMutChroms <- sort(unique(lethMutChroms))
      }
      if(numLethMuts == 0){
        lethMutChroms <- 0
      }
      mutChromVec <- NULL
      for(y in 1:chrNum){
        if(sum(lethMutChroms == y) > 0){
          thisChrom <- y
          thisChromMutInfo <- NULL    # matrix storing SNP location information
          thisMutLocs <- lethMutLocs[which(lethMutChroms == thisChrom)]
          thisMutClass <- rep("lethal",length(thisMutLocs))
          theseMutInds <- lethMutInds[which(lethMutChroms == thisChrom)]
          theseSnpPos <- snpMat[which(snpMat[,1] == thisChrom),2]
          theseSnpClasses <- snpMat[which(snpMat[,1] == thisChrom),3]
          theseMutChrCopy <- lethMutChrCopy[which(lethMutChroms == thisChrom)]
          thisChromMutInfo <- cbind(thisChromMutInfo,thisMutLocs,theseMutInds,theseMutChrCopy)
          if(is.null(nrow(thisChromMutInfo)) == FALSE){
            thisChromMutInfo <- thisChromMutInfo[order(thisChromMutInfo[,1]),]
          }
          newChr1 <- matrix("T",nrow=nrow(offChr1[[1]]),ncol=length(thisMutLocs))    # genotypes at newly mutated nucleotide positions
          newChr2 <- matrix("T",nrow=nrow(offChr1[[1]]),ncol=length(thisMutLocs))
          if(is.null(nrow(thisChromMutInfo)) == FALSE){
            for(z in 1:length(thisMutLocs)){
              if(thisChromMutInfo[z,3] == 1) newChr1[thisChromMutInfo[z,2],z] <- "A"
              if(thisChromMutInfo[z,3] == 2) newChr2[thisChromMutInfo[z,2],z] <- "A"
            }
          }
          if(is.null(nrow(thisChromMutInfo))){
            if(thisChromMutInfo[3] == 1) newChr1[thisChromMutInfo[2],] <- "A"
            if(thisChromMutInfo[3] == 2) newChr2[thisChromMutInfo[2],] <- "A"
          }

          #-----------------------------------------------------------------------------------------------------
          # add mutated genotype to the mutated chromosome and wild type genotypes to the other chromosome copy
          #-----------------------------------------------------------------------------------------------------
          outChr1 <- cbind(offChr1[[y]][,2:ncol(offChr1[[y]])],newChr1)
          outChr2 <- cbind(offChr2[[y]][,2:ncol(offChr2[[y]])],newChr2)
          if(is.null(nrow(thisChromMutInfo)) == FALSE) sortInfo <- as.numeric(c(theseSnpPos,thisChromMutInfo[,1]))
          if(is.null(nrow(thisChromMutInfo))) sortInfo <- as.numeric(c(theseSnpPos,thisChromMutInfo[1]))
          outChr1 <- outChr1[,order(sortInfo)]
          outChr2 <- outChr2[,order(sortInfo)]
          if(sum(is.na(outChr2)) > 0) stop("missing genotype, lethal")
          outChr1List[[y]] <- outChr1
          outChr2List[[y]] <- outChr2

          #-----------------------------------------------------------------------------------------------------
          # record the new SNP position in the genome in snpMat
          #-----------------------------------------------------------------------------------------------------
          if(is.null(nrow(thisChromMutInfo)) == FALSE)  newPosVec <- c(theseSnpPos,thisChromMutInfo[,1])[order(sortInfo)]
          if(is.null(nrow(thisChromMutInfo)))  newPosVec <- c(theseSnpPos,thisChromMutInfo[1])[order(sortInfo)]
          newClassVec <- c(theseSnpClasses,thisMutClass)[order(sortInfo)]
          newSnpBlock <- cbind(rep(y,length(newPosVec)),as.character(newPosVec),newClassVec)
          snpMat <- snpMat[-which(snpMat[,1] == y),]
          if(sum(snpMat[,1] < newSnpBlock[1,1]) == 0   & sum(snpMat[,1] > newSnpBlock[1,1]) > 0) snpMat <- rbind(newSnpBlock,snpMat[which(snpMat[,1] > newSnpBlock[1,1]),])
          if(sum(snpMat[,1] < newSnpBlock[1,1]) > 0   & sum(snpMat[,1] > newSnpBlock[1,1]) > 0) snpMat <- rbind(snpMat[which(snpMat[,1] < newSnpBlock[1,1]),],newSnpBlock,snpMat[which(snpMat[,1] > newSnpBlock[1,1]),])
          if(sum(snpMat[,1] < newSnpBlock[1,1]) > 0   & sum(snpMat[,1] > newSnpBlock[1,1]) == 0) snpMat <- rbind(snpMat[which(snpMat[,1] < newSnpBlock[1,1]),],newSnpBlock)
          thisOutMutInfo <- rbind(thisOutMutInfo,thisChromMutInfo)
          mutChromVec <- c(mutChromVec,rep(thisChrom,length(thisMutLocs)))
        }
        if(sum(lethMutChroms == y) == 0) {
          outChr1 <- offChr1[[y]][,2:ncol(offChr1[[y]])]
          outChr2 <- offChr2[[y]][,2:ncol(offChr2[[y]])]
          outChr1List[[y]] <- outChr1
          outChr2List[[y]] <- outChr2
        }
      }

      ########## partially recessive detrimental mutations
      if(numDetMuts > 0){
        detMutLocs <- runif(numDetMuts,min=0,max=chrLengs[1])
        detMutChroms <- sample(1:chrNum,numDetMuts,replace=TRUE)
        detMutChrCopy <- sample(1:2,size=numDetMuts,replace=TRUE)
        detMutInds <- sample(1:nrow(outChr1List[[1]]),numDetMuts,replace=TRUE)
        uniqMutChroms <- sort(unique(detMutChroms))
        thisOutMutInfo <- NULL
        mutChromVec <- NULL
        for(y in 1:chrNum){
          if(sum(uniqMutChroms == y) > 0){
            thisChrom <- y
            thisChromMutInfo <- NULL    # matrix storing SNP location information
            thisMutLocs <- detMutLocs[which(detMutChroms == thisChrom)]
            theseMutInds <- detMutInds[which(detMutChroms == thisChrom)]
            theseSnpPos <- as.numeric(snpMat[which(snpMat[,1] == thisChrom),2])
            theseMutChrCopy <- detMutChrCopy[which(detMutChroms == thisChrom)]
            thisChromMutInfo <- cbind(thisChromMutInfo,thisMutLocs,theseMutInds,theseMutChrCopy)
            if(is.null(thisChromMutInfo) == FALSE){
              thisChromMutInfo <- thisChromMutInfo[order(thisChromMutInfo[,1]),]
            }
            newChr1 <- matrix("T",nrow=nrow(outChr1List[[1]]),ncol=length(thisMutLocs))    # genotypes at newly mutated nucleotide positions
            newChr2 <- matrix("T",nrow=nrow(outChr1List[[1]]),ncol=length(thisMutLocs))
            if(is.null(nrow(thisChromMutInfo)) == FALSE){
              for(z in 1:length(thisMutLocs)){
                if(thisChromMutInfo[z,3] == 1) newChr1[thisChromMutInfo[z,2],z] <- "A"
                if(thisChromMutInfo[z,3] == 2) newChr2[thisChromMutInfo[z,2],z] <- "A"
              }
            }
            if(is.null(nrow(thisChromMutInfo))){
              if(thisChromMutInfo[3] == 1) newChr1[thisChromMutInfo[2],] <- "A"
              if(thisChromMutInfo[3] == 2) newChr2[thisChromMutInfo[2],] <- "A"
            }

            #-----------------------------------------------------------------------------------------------------
            # add mutated genotype to the mutated chromosome and wild type genotypes to the other chromosome copy
            #-----------------------------------------------------------------------------------------------------
            outChr1 <- cbind(outChr1List[[y]],newChr1)
            outChr2 <- cbind(outChr2List[[y]],newChr2)
            if(is.null(nrow(thisChromMutInfo)) == FALSE) sortInfo <- as.numeric(c(theseSnpPos,thisChromMutInfo[,1]))
            if(is.null(nrow(thisChromMutInfo))) sortInfo <- as.numeric(c(theseSnpPos,thisChromMutInfo[1]))
            outChr1 <- outChr1[,order(sortInfo)]
            outChr2 <- outChr2[,order(sortInfo)]
            if(is.null(nrow(thisChromMutInfo)) == FALSE) newPosVec <- c(theseSnpPos,thisChromMutInfo[,1])[order(sortInfo)]
            if(is.null(nrow(thisChromMutInfo))) newPosVec <- c(theseSnpPos,thisChromMutInfo[1])
            if(sum(is.na(outChr2)) > 0) stop("missing genotype, detrimental")
            outChr1List[[y]] <- outChr1
            outChr2List[[y]] <- outChr2
            if(outChr1[1,2] %in% c("A","T") == FALSE) stop("bad outChr1")
            #-----------------------------------------------------------------------------------------------------
            # record the new SNP position in the genome in snpMat
            #-----------------------------------------------------------------------------------------------------
            oldSnpClasses <- snpMat[which(snpMat[,1] == y),3]
            newSnpClasses <- rep("det",length(thisMutLocs))
            outSnpClasses <- c(oldSnpClasses,newSnpClasses)[order(sortInfo)]
            outSnpBlock <- cbind(rep(thisChrom,length(outSnpClasses)),newPosVec,outSnpClasses)
            colnames(outSnpBlock) <- c("snpChrs","snpPos","")
            snpMat <- snpMat[-which(snpMat[,1] == y),]
            if(sum(snpMat[,1] < outSnpBlock[1,1]) == 0   & sum(snpMat[,1] > outSnpBlock[1,1]) > 0) snpMat <- rbind(outSnpBlock,snpMat[which(snpMat[,1] > outSnpBlock[1,1]),])
            if(sum(snpMat[,1] < outSnpBlock[1,1]) > 0   & sum(snpMat[,1] > outSnpBlock[1,1]) > 0) snpMat <- rbind(snpMat[which(snpMat[,1] < outSnpBlock[1,1]),],outSnpBlock,snpMat[which(snpMat[,1] > outSnpBlock[1,1]),])
            if(sum(snpMat[,1] < outSnpBlock[1,1]) > 0   & sum(snpMat[,1] > outSnpBlock[1,1]) == 0) snpMat <- rbind(snpMat[which(snpMat[,1] < outSnpBlock[1,1]),],outSnpBlock)
            thisOutMutInfo <- rbind(thisOutMutInfo,thisChromMutInfo)
            mutChromVec <- c(mutChromVec,rep(thisChrom,length(thisMutLocs)))
          }
        }
        thisOutMutInfo <- cbind(mutChromVec,thisOutMutInfo,rep("det",nrow(thisOutMutInfo)))
        outMutInfo <- rbind(outMutInfo,thisOutMutInfo)
      } # end detrimental mutations

      if(sum(is.na(offChr2[[1]])) == 0){
        for(y in 1:chrNum){
          outChr1List[[y]] <- cbind(id,outChr1List[[y]])
          outChr2List[[y]] <- cbind(id,outChr2List[[y]])
        }
        chr1List <- outChr1List
        chr2List <- outChr2List
        chr1OrigList <- offChr1Orig
        chr2OrigList <- offChr2Orig
      }
      if(extinct == FALSE & sum(is.na(offChr2[[1]])) > 0){print("ERRORRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR")}
    } # end if statement checking for > 0 offspring in generation i
    if(extinct == FALSE & sum(is.na(offChr2[[1]])) > 0){stop("bad error")}
    print(paste("done with generation ",i,sep=""))
    print(paste("population size = ",length(id)))
    print(paste("Inbreeding load (B) = ", round(BVec[length(BVec)],digits= 2),sep=""))
    print(paste("Genetic load (L) = ", round(LVec[length(LVec)],digits=3)))
    if(extinct == TRUE){print(paste("population extinct at generation ",i,sep=""))}

    ##################################################################
    # save genotype files for this generation
    ##################################################################

    if(saveGenGenos == TRUE){
      genoGen1Mat <- NULL
      genoGen2Mat <- NULL
      origGen1Mat <- NULL
      origGen2Mat <- NULL
      for(z in 1:chrNum){
        if(z == 1){
          genoGen1Mat <- cbind(genoGen1Mat,chr1List[[z]])
          genoGen2Mat <- cbind(genoGen2Mat,chr2List[[z]])
          origGen1Mat  <- cbind(origGen1Mat,chr1OrigList[[z]])
          origGen2Mat  <- cbind(origGen2Mat,chr2OrigList[[z]])
        }
        if(z > 1){
          genoGen1Mat <- cbind(genoGen1Mat,chr1List[[z]][,2:ncol(chr1List[[z]])])
          genoGen2Mat <- cbind(genoGen2Mat,chr2List[[z]][,2:ncol(chr2List[[z]])])
          origGen1Mat  <- cbind(origGen1Mat,chr1OrigList[[z]][,2:ncol(chr1OrigList[[z]])])
          origGen2Mat  <- cbind(origGen2Mat,chr2OrigList[[z]][,2:ncol(chr2OrigList[[z]])])
        }
      }
      write.table(genoGen1Mat,file=paste("generation_",i,"_chr1_genos",sep=""),row.names=FALSE,col.names=FALSE,quote=FALSE)
      write.table(genoGen2Mat,file=paste("generation_",i,"_chr2_genos",sep=""),row.names=FALSE,col.names=FALSE,quote=FALSE)
      write.table(snpMat,file=paste("snpMap_generation_",i,sep=""),col.names=FALSE,row.names=FALSE,quote=FALSE)
    }
    i <- i + 1
  }

  # finish the inbreeding vector if needed
  if(length(inbVec) < nrow(pedObject)){
    thisIBDVec <- rep(0,nrow(chr1OrigList[[1]]))   # number of IBD chromosome segments for each individual
    for(y in 1:chrNum){
      thisIBDVec <- thisIBDVec + rowSums(chr1OrigList[[y]][,2:ncol(chr1OrigList[[y]])] == chr2OrigList[[y]][,2:ncol(chr2OrigList[[y]])])
    }
    inbVec <- c(inbVec,thisIBDVec/(simLociNum*chrNum))

  }
  if(length(survVec) < nrow(pedObject)) survVec <- c(survVec,rep(NA,nrow(pedObject) - length(survVec)))
  pedObject <- cbind(pedObject,survVec)
  geno1Mat <- NULL
  geno2Mat <- NULL
  orig1Mat <- NULL
  orig2Mat <- NULL
  for(i in 1:chrNum){
    if(i == 1){
      geno1Mat <- cbind(geno1Mat,chr1List[[i]])
      geno2Mat <- cbind(geno2Mat,chr2List[[i]])
      orig1Mat  <- cbind(orig1Mat,chr1OrigList[[i]])
      orig2Mat  <- cbind(orig2Mat,chr2OrigList[[i]])
    }
    if(i > 1){
      geno1Mat <- cbind(geno1Mat,chr1List[[i]][,2:ncol(chr1List[[i]])])
      geno2Mat <- cbind(geno2Mat,chr2List[[i]][,2:ncol(chr2List[[i]])])
      orig1Mat  <- cbind(orig1Mat,chr1OrigList[[i]][,2:ncol(chr1OrigList[[i]])])
      orig2Mat  <- cbind(orig2Mat,chr2OrigList[[i]][,2:ncol(chr2OrigList[[i]])])
    }
  }
  pedObject <- cbind(pedObject,inbVec) # save genomic inbreeding for each individual

  #### outputs
  pedObject <<- pedObject
  geno1Mat <<-  geno1Mat
  geno2Mat <<-  geno2Mat
  orig1Mat <<-  orig1Mat
  orig2Mat <<-  orig2Mat
  snpOrigMat <<- snpOrigMat
  snpMat <<- snpMat
  BVec <<- BVec
  LVec <<- LVec
  NVec <<- NVec
  L_equil <<- L_equil
  B_equil <<- B_equil
  print("**********simulation done**********")
}

