#' This function runs a forward-time genomic, spatially-explicit simulation of evolution in a closed population. The simulation
#' saves the entire pedigree, genotypes at any number of simulated loci distributed evenly over any number of chromosomes,
#' and allele frequencies throughout the simulation.
#'
#' @param nChromLoci Number of evenly spaced loci to put on each chromosome.
#'     This is also the number of chromosome segments followed through the pedigree.
#' @param chrNum Number of simulated chromosomes. Must equal the length of chrLengs physLengs (see below). This will be overridden if a map file is provided
#' @param chrLengs Chromosome map length in centiMorgans (set to 50 or 100).
#' @param physLengs Vector of length chrNum giving the physical chromosome lengths in Megabases. This will be overridden if a map file is provided
#' @param beta1 First shape parameter for the beta distribution for simulating source population allele frequencies
#' @param beta2 Second shape parameter for the beta distribution for simulating source population allele frequencies
#' @param numAlleles Number of microsatellite equally frequent microsatellite alleles per locus in the founding generation of the simulation. Allele frequencies
#'     are allowed to drift as the simulation proceeds.
#' @param gens Number of non-overlapping generations to simulate
#' @param popSize Permanent adult population size. Must be a positive integer
#' @param meanClutch Mean clutch size in the population. 0.5N female and 0.5N male offspring are selected at random to survive to breed.
#' @param sdClutch Standard deviation in clutch size. We assume normally distributed clutch sizes.
#' @param epyRate Probability of an offspring being extra-pair assumin the mosther has participated in an extra pair copulation.
#' @param baseEPC Mean number of extra pair copulations per breeding female, assumbed to be Poisson distributed.
#' @param epcSlope the rate of linear increase in the mean number of extra pair copulations per female with increasing genomic kinship to the behavioural mates.
#' @param habSize 2-dimensional habitat size, expressed as a single number giving the square side length.
#' @param femDispDist Mean dispersal distance for females
#' @param maleDispDist Mean dispersal distance for males
#' @param matingDistRate Exponential rate of decline with increasing distance in the probability of a female selecting
#'     a male as a mate. Females are more likely mate with close-by males. Note that each parental pair is permanent, but extra-pair paternities are allowed (see below)
#'     of beta1 an beta2 (see below). We then assign diploid genotypes to the founders and immigrants assuming Hardy-Weinberg proportions and
#'     no linkage disequilibrium in the source population. Will be overriden when genotypes are imported (see genoImport below)
#' @param getPedKinship Whether to calculate pedigree-based kinship of the realized parents (accounting for extra-pair paternity) for each offspring (set to TRUE of FALSE). Setting
#'     to TRUE will slow the simulation down considerably for large population sizes.
#' @param burnin Number of generations with clutch size = 2. Afther this many generation, clutch sizes with be distributed as designated with meanClutch and sdClutch.
#'
#'
#' @details
#'    Output includes 9 objects:
#'
#'    pedObject is a matrix with one row for each individual and 17 columns including a unique indiviudal identifier (id); the ids
#'    of the two parents (mom and dad, accounting for extra-pair paternities); the generation the individual was born in (gen);
#'    the age of the individual (set to 0 for all individuals here because generations are non-overlapping)(age);
#'    whether the individual is an immigrant (0 = locally born,1 = immigrant founder)(immVec); the individual's location on the x-axis (xLoc);
#'    the individual's location on the y-axis (yLoc); whether the individual was alive (set to 1=alive for all individuals here as there are non-overlapping generations);
#'    whether the individual is the offspring of extra-pair copulation (epp; 1=extra-pair paternity; 0=offspring of behavioral parents);
#'    the genomic kinship of the behavioral parents (parKinship). This is calculated as the fraction of the behavioral parents' genomes shared identical-by-descent; the genomic kinship
#'    between the mother and the extra-pair father (eppKinship, only given for offspring of extra-pair paternity); heterozygosity of at the simulated SNPs (het);
#'    heterozygosity at the simulated microsatellites (msatHet)
#'

#'    hapMat1 and hapMat2 are data frames with rows for individuals, and columns for haplotype identity of each segment on the
#'    chromosome. hapMat1 and hapMat2 give the haplotype identities for chromosome copies one and two, respectively.
#'
#'    genoMat1 and genoMat2 give SNP the genotypes at each simulated locus.
#'
#'    msat1Mat and msat2Mat give the first and second microsattelite alleles for each individual and each locus
#'
#'    allFreqMat is a data frame storing the allele frequency at every simulated SNP throughout the simulation.
#'
#'    lociMap gives the mapping positions of each locus in the genome. The first column gives the chromosome number, and the second column
#'    gives the position of the locus in centiMorgans.
#'
#'
#'
#' @return
#'
#' @examples
#'
#'
#' @importFrom stats rbeta rexp rnorm rpois runif var lm
#' @importFrom utils read.table
#'
#' @export
#'
pedSim_spatial_extPair <- function(nChromLoci,chrNum,chrLengs,physLengs,beta1,beta2,numAlleles,gens,popSize,habSize,femDispDist,maleDispDist,matingDistRate,
                                        meanClutch,sdClutch,epyRate,baseEPC,epcSlope,getPedKinship,burnin){
  if(beta1 <= 0 | beta2 <= 0)stop("beta1 and beta2 must be positive")
  if(is.null(popSize) == TRUE) stop("must specify population size")
  if(length(popSize) != 1)stop("popSize must be a single integer giving the population size")
  if(sum(popSize < 1) > 0)stop("popSize must be a positive integer)")
  if(chrLengs %in% c(50,100) == FALSE) stop("chrLengs must be either 50 or 100 (cM)")
  id <- 1:popSize[1]
  mom <- rep(NA,popSize[1])
  dad <- rep(NA,popSize[1])
  gen <- rep(1,length(id))
  age <- rep(0,length(id))
  sex <- rep(c(0,1),popSize)[1:popSize]
  pedObject <- cbind(id,mom,dad,gen,age,sex)    # store the simulated pedigree information
  ################################################################
  # initialize founder and immigrant chromosome segment identities
  ################################################################
  immVec <- rep(0,popSize)   # indicator variable for immigrants
  imms <- which(is.na(pedObject[,2]) == TRUE)  # identify the founders and immigrants
  immVec[imms] <- 1
  pedObject <- cbind(pedObject,immVec)

  ###########################################
  # initialize the genome matrices: NEW
  ###########################################
  chr1List <- list()     # list of chromosome data from the first chromosome copy
  chr2List <- list()     # list of chromosome data from the second chromosome copy
  for(i in 1:chrNum){
    chrAllFreqs <- rbeta(n=nChromLoci,shape1=beta1,shape2=beta2)
    thisChr1 <- matrix(NA,nrow=popSize,ncol=nChromLoci)
    thisChr2 <- matrix(NA,nrow=popSize,ncol=nChromLoci)
    for (j in 1:ncol(thisChr1)){
      thisChr1[,j] <- runif(popSize,min=0,max=1) < chrAllFreqs[j]
      thisChr2[,j] <- runif(popSize,min=0,max=1) < chrAllFreqs[j]
    }
    chr1List [[i]]<- thisChr1   ### 1's indicate that each individual in the original population is pure native
    chr2List [[i]]<- thisChr2   ### 1's indicate that each individual in the original population is pure native
  }
  idVec <- 1:popSize             # vector of individual identities
  #################################################
  # initialize the haplotype identity matrices: NEW
  #################################################
  hap1List <- list()     # list of chromosome data from the first chromosome copy
  hap2List <- list()     # list of chromosome data from the second chromosome copy
  hapIDInitialize <- matrix(1:(2*popSize),nrow=popSize,ncol=2,byrow=TRUE)
  for(i in 1:chrNum){
    thisChr1 <- matrix(NA,nrow=popSize,ncol=nChromLoci)
    thisChr2 <- matrix(NA,nrow=popSize,ncol=nChromLoci)
    for (j in 1:nrow(thisChr1)){
      thisChr1[j,] <- rep(hapIDInitialize[j,1],ncol(thisChr1))
      thisChr2[j,] <- rep(hapIDInitialize[j,2],ncol(thisChr1))
    }
    hap1List [[i]]<- thisChr1   ### 1's indicate that each individual in the original population is pure native
    hap2List [[i]]<- thisChr2   ### 1's indicate that each individual in the original population is pure native
  }

  foundChr1List <- chr1List
  foundChr2List <- chr2List
  foundHap1List <- hap1List
  foundHap2List <- hap2List
  ############################################
  # make map object for all the loci
  ############################################
  lociMap <- NULL
  for (j in 1:chrNum){
    chr <- rep(j,nChromLoci)
    pos <- seq(0,chrLengs,chrLengs/(nChromLoci-1))
    thisMap <- cbind(chr,pos)
    lociMap <- rbind(lociMap,thisMap)
  }

  ################################################################
  # assign location of each individual on a 2-dimensional surface
  ################################################################
  xLoc <- runif(n=length(id),min=0,max=habSize) # random x coordinate
  yLoc <- runif(n=length(id),min=0,max=habSize) # random y coordinate
  pedObject <- cbind(pedObject,xLoc,yLoc)
  alive <- rep(1,nrow(pedObject))
  pedObject <- cbind(pedObject,alive)

  #################################################
  # keep track of allele frequencies
  #################################################
  allFreqMat <- matrix(NA,nrow=gens,ncol=nChromLoci*chrNum)

  ######################################
  # simulate 2:gens generations
  ######################################
  i <- 2            # iterate over generations
  extinct <- FALSE  # the population size is > 0 to start
  epp <- rep(FALSE,nrow(pedObject))     # indicate that none of the founders result from extra-pair paternity
  parKinship <- rep(0,nrow(pedObject))  # indicate that all parents of founders were unrelated
  parPedKinship <- rep(0,nrow(pedObject))
  eppKinship <- rep(NA,nrow(pedObject))
  pedObject <- cbind(pedObject,epp,parKinship,eppKinship)  # initialize object to store pedigree information
  pedObject <- rbind(pedObject,matrix(NA,nrow=0.5*popSize*meanClutch*gens+0.1*(0.5*popSize*meanClutch*gens),ncol=ncol(pedObject)))
  indHets <- NULL
  snpLocs <- lociMap[which(lociMap[,1] == 1),2]
  while(i <= gens){
    ##################################################
    # dispersal of juveniles
    ##################################################
    juvies <- NULL
    juvies <- which (pedObject[,5] == 0 & pedObject[,10] == 1)
    juvieMat <- pedObject[juvies,]
    juvXLoc <- pedObject[juvies,8] # location of each juvie in the 2D space
    juvYLoc <- pedObject[juvies,9]
    expRate <- rep(NA,length(juvies))
    expRate[which(juvieMat[,6] == 0)] <- 1/femDispDist
    expRate[which(juvieMat[,6] == 1)] <- 1/maleDispDist

    ###############################################
    # assign new X and Y location for each juvenile
    ###############################################
    newX <- rep(NA,length(juvXLoc))
    newY <- rep(NA,length(juvYLoc))
    candX <- seq(0,habSize,habSize/500)    # all possible new locations
    candY <- seq(0,habSize,habSize/500)
    for(j in 1:length(newX)){
      newX [j] <- sample(candX,1,prob=dexp(abs(candX-juvXLoc[j]),rate=expRate[j]))
      newY [j] <- sample(candY,1,prob=dexp(abs(candY-juvYLoc[j]),rate=expRate[j]))
    }
    pedObject[juvies,8] <- newX
    pedObject[juvies,9] <- newY
    survIDs <- pedObject[which(pedObject[,10] == 1),1]

      ########################
      # identify the mothers
      ########################
      moms <- pedObject[which(pedObject[,4] == i-1 & pedObject[,6] == 0 & pedObject[,10] == 1),1]

      ######################################################
      # pair fathers with mothers
      ######################################################
      dads <- rep(NA,length(moms))   # males that will be used as for extra-pair paternities
      momLocs <- pedObject[match(moms,pedObject[,1]),8:9]   # xy coordinates of mothers
      possibleDads <- pedObject[which(pedObject[,4] == i-1 & pedObject[,6] == 1 & pedObject[,10] == 1),1]   # identify potential mates for each female
      maleLocs <- pedObject[match(possibleDads,pedObject[,1]),8:9]
      maleDistMatrix <- matrix(NA,nrow=length(moms),ncol=nrow(maleLocs))
      for(z in 1:length(moms)){
        femLoc <- matrix(rep(momLocs[z,],nrow(maleLocs)),nrow=nrow(maleLocs),ncol=2,byrow=TRUE)                     # calculate the distance from the focal female to each of the males
        toMaleDist <- sqrt((femLoc[,1]-maleLocs[,1])^2+(femLoc[,2]-maleLocs[,2])^2)
        distWeights <- dexp(toMaleDist,rate=matingDistRate)
        dads [z] <- sample(possibleDads,size=1,prob= distWeights,replace=FALSE)
        maleDistMatrix[,z] <- toMaleDist
      }

    ####################################################################
    # assign family sizes, randomly assigning each offspring to mothers
    ####################################################################
    if(i <= burnin) nOffs <- rep(2,length(moms))
    if(i > burnin) nOffs <- round(rnorm(length(moms),mean=meanClutch,sd=sdClutch))

    ########################################################
    # collect the behavioural moms' and dads' genomes
    #######################################################
    behavMomGenome1 <- NULL
    behavMomGenome2 <- NULL
    behavDadGenome1 <- NULL
    behavDadGenome2 <- NULL
    for(vb in 1:chrNum){
      behavMomGenome1 <- cbind(behavMomGenome1,hap1List[[vb]][match(moms,idVec),])
      behavMomGenome2 <- cbind(behavMomGenome2,hap2List[[vb]][match(moms,idVec),])
      behavDadGenome1 <- cbind(behavDadGenome1,hap1List[[vb]][match(dads,idVec),])
      behavDadGenome2 <- cbind(behavDadGenome2,hap2List[[vb]][match(dads,idVec),])
    }

    #-------------------------------------------------------
    # now calcualte the IBD fraction for each parent pair
    # then assign the number of extra-pair copulations
    #-------------------------------------------------------
    parIBDFraction <- rep(NA,length(moms))   # IBD fraction for the behavioural pair
    EPCs <- rep(0,length(moms))              # number of extra-pair copulations to assign to the mother
    EPYs <- rep(NA,length(moms))             # number of extra-pair offspring the mother will have
    for(vb in 1:length(moms)){
      momGenome <- rbind(behavMomGenome1[vb,],behavMomGenome2[vb,])
      dadGenome <- rbind(behavDadGenome1[vb,],behavDadGenome2[vb,])
      parIBDFraction[vb] <- mean(colMeans(rbind(colSums(dadGenome == rbind(momGenome[1,],momGenome[1,]))/2, colSums(dadGenome == rbind(momGenome[2,],momGenome[2,]))/2)))
      EPCs [vb] <- rpois(1,lambda = baseEPC + epcSlope*parIBDFraction[vb])
      EPYs [vb] <- sum(rbinom(nOffs[vb],1,prob=epyRate*EPCs[vb]))
    }

    ###################################################
    # assign IDs for new offspring (if there are any)
    ###################################################
      #theseInds <- (nrow(pedObject)+1):(nrow(pedObject)+ sum(nOffs))  # vector of non-immgrant individuals to assign haplotypes to
      #imms <- c(imms,theseInds)
      id <-  (max(pedObject[,1],na.rm=TRUE)+1):(max(pedObject[,1],na.rm=TRUE)+sum(nOffs))
      gen <- rep(i, length(id))
      mom <- NULL
      dad <- NULL
      offLoc <- NULL
      parKinship <- NULL # vector to keep track of parental kinship
      epp <- NULL    # vector to keep track of EPP status of each offspring
      for(z in 1:length(moms)){
        if(nOffs[z] > 0){
          mom <- c(mom,rep(moms[z],nOffs[z]))
          for(zv in 1:nOffs[z]){
            offLoc <- rbind(offLoc,momLocs[z,])
          }
          theseDad <- rep(dads[z],nOffs[z])
          theseEpp <- rep(0,nOffs[z])
          ###############################################
          # introduce extrapair paternities if necessary
          ###############################################
          thisOffMom <- moms[z]
          thisOffDad <- dads[z]
          parGenomKin <- rep(parIBDFraction[moms == thisOffMom & dads == thisOffDad],nOffs[z])
          parKinship <- c(parKinship,parGenomKin)
          if(EPYs[z] > 0){
            thesePossibleDads <- possibleDads[-which(possibleDads == dads[z])]
            toMaleDist <- maleDistMatrix[which(moms == moms[z]),which(possibleDads %in% thesePossibleDads)]
            distWeights <- dexp(toMaleDist,rate=matingDistRate)
            newDad <- sample(thesePossibleDads,size=1,prob= distWeights,replace=FALSE)
            eppOffs <- sample(1:nOffs[z],EPYs[z],replace=FALSE)
            theseDad[eppOffs] <- newDad
            theseEpp[eppOffs] <- 1
          }
          dad <- c(dad,theseDad)
          epp <- c(epp,theseEpp)
        }
      }
      offSex <- rep(c(0,1),length(id))[1:length(id)]
      offAge <- rep(0,length(id))
      offImmVec <- rep(0,length(id))
      offAlive <- rep(0,length(id))                                          # keep 0.5 x N females and males alive
      offAlive[sample(which(offSex == 0),0.5*popSize,replace=FALSE)] <- 1
      offAlive[sample(which(offSex == 1),0.5*popSize,replace=FALSE)] <- 1

      ###################################################################################################################
      # calculate the pairwise IBD fraction of the genome for the parents of each offspring
      # resulting from extra-pair copulation
      ###################################################################################################################
      #-------------------------------------------------------------------------
      # first make matrices of haploptype identities for the mothers and fathers
      #-------------------------------------------------------------------------
      eppMoms <- mom[which(epp == TRUE)]
      eppDads <- dad[which(epp == TRUE)]

      ########################################################
      # collect the EPP moms' and dads' genomes
      #######################################################
      eppMomGenome1 <- NULL
      eppMomGenome2 <- NULL
      eppDadGenome1 <- NULL
      eppDadGenome2 <- NULL
      for(vb in 1:chrNum){
        eppMomGenome1 <- cbind(eppMomGenome1,hap1List[[vb]][match(eppMoms,idVec),])
        eppMomGenome2 <- cbind(eppMomGenome2,hap2List[[vb]][match(eppMoms,idVec),])
        eppDadGenome1 <- cbind(eppDadGenome1,hap1List[[vb]][match(eppDads,idVec),])
        eppDadGenome2 <- cbind(eppDadGenome2,hap2List[[vb]][match(eppDads,idVec),])
      }
      eppIBDFraction <- rep(NA,length(eppMoms))   # IBD fraction for the behavioural pair
      for(vb in 1:length(eppMoms)){
        momGenome <- rbind(eppMomGenome1[vb,],eppMomGenome2[vb,])
        dadGenome <- rbind(eppDadGenome1[vb,],eppDadGenome2[vb,])
        eppIBDFraction[vb] <- mean(colMeans(rbind(colSums(dadGenome == rbind(momGenome[1,],momGenome[1,]))/2, colSums(dadGenome == rbind(momGenome[2,],momGenome[2,]))/2)))
      }

      #----------------------------------------------------------------------------------
      # save the genomic kinship of the behavioural parents and the extra-pair parents
      #----------------------------------------------------------------------------------
      eppKinship <- rep(NA,length(epp))
      eppKinship[epp == TRUE] <- eppIBDFraction

      ####### collect pedigree kinships of the parents
      if(getPedKinship == TRUE){
        pedKins <- kinship(id=pedObject[,1],dadid = pedObject[,3],momid=pedObject[,2])
        parPedKins <- rep(NA,length(mom))
        for(z in 1:length(mom)){
          parPedKins [z]<- pedKins[ mom[z],dad[z]]
        }
        parPedKinship <- c(parPedKinship,parPedKins)
      }
      if(getPedKinship == FALSE){
        parPedKinship <- c(parPedKinship,rep(NA,length(id)))
      }
      outDat <- cbind(id,mom,dad,gen,offAge,offSex,offImmVec,offLoc,offAlive,epp,parKinship,eppKinship)

      fstAddRow <- which(is.na(pedObject[,1]) == TRUE)[1]
      lastAddRow <- fstAddRow + nrow(outDat) - 1
      pedObject[fstAddRow:lastAddRow,] <- outDat

      ########################################
      # meiosis
      ########################################
      posMat <- matrix(rep(lociMap[which(lociMap[,1] == 1),2]),nrow=length(id),ncol=sum(lociMap[,1] ==1),byrow=TRUE) # a matrix of locus positions on the chromosome
      for(k in 1:chrNum){
        momsCopy1 <- chr1List[[k]][match(mom,idVec),]
        dadsCopy1 <- chr1List[[k]][match(dad,idVec),]
        momsCopy2 <- chr2List[[k]][match(mom,idVec),]
        dadsCopy2 <- chr2List[[k]][match(dad,idVec),]

        momsHap1 <- hap1List[[k]][match(mom,idVec),]
        dadsHap1 <- hap1List[[k]][match(dad,idVec),]
        momsHap2 <- hap2List[[k]][match(mom,idVec),]
        dadsHap2 <- hap2List[[k]][match(dad,idVec),]

        #----------------------------
        # maternal meiosis
        #----------------------------
        if(chrLengs == 50)momRecs <- sample(c(0,1),length(id),replace=TRUE)
        if(chrLengs == 100)momRecs <- rep(1,length(id))
        #momRecs <- rpois(n=length(id),lambda=chrLengs/100)    # number of recombination events in the mom
        momRecLocsMat <- matrix(NA,nrow=length(id),ncol=max(momRecs)+1)
        for(z in 1:ncol(momRecLocsMat)){   # draw locations of crossovers for all individuals
          momRecLocsMat[which(momRecs >= z),z] <- runif(n=length(which(momRecs >= z)),min=0,max=chrLengs)
          if(sum(momRecs == (z-1)) > 0) momRecLocsMat[which(momRecs == (z-1)),z] <- chrLengs
        }
        if(sum(momRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(momRecs > 1)
          for(b in moreThanOneRec){
            momRecLocsMat[b,1:(momRecs[b]+1)] <- sort(momRecLocsMat[b,])
          }
        }
        momRecLocsMat[,ncol(momRecLocsMat)] <- rep(chrLengs,nrow(momRecLocsMat))
        momChrPicker <- sample(x=c(1,2),size=length(id),replace=TRUE) # which parental chromosome copy to sample first
        outMomGenoList <- list() # store the maternal genotypes in segments between crossovers
        outMomHapList <- list()
        recPosList <- list() # store the positions of recombination revents

        for(b in 1:2){
          thisMomGenoMat <- matrix(NA,ncol=nChromLoci,nrow=length(id))
          thisMomHapMat <- matrix(NA,ncol=nChromLoci,nrow=length(id))
          if(sum(momChrPicker == 1) > 0){
            thisMomGenoMat[which(momChrPicker == 1),] <-  momsCopy1[which(momChrPicker == 1),]
            thisMomHapMat[which(momChrPicker == 1),] <-  momsHap1[which(momChrPicker == 1),]
          }
          if(sum(momChrPicker == 2) > 0){
            thisMomGenoMat[which(momChrPicker == 2),] <-  momsCopy2[which(momChrPicker == 2),]
            thisMomHapMat[which(momChrPicker == 2),] <-  momsHap2[which(momChrPicker == 2),]
          }
          if(b==1){
             recMat <- matrix(rep(momRecLocsMat[,1],ncol(thisMomGenoMat)),nrow=nrow(momRecLocsMat),ncol=ncol(thisMomGenoMat))
             recMat <- replace(recMat, is.na(recMat), chrLengs)
             thisMomGenoMat[posMat > recMat] <- FALSE   # make all snp genotypes and haplotype identities past the recombination events missing
             thisMomHapMat[posMat > recMat] <- 0
          }
          if(b==2){
            recMat <- matrix(rep(momRecLocsMat[,b],ncol(thisMomGenoMat)),nrow=nrow(momRecLocsMat),ncol=ncol(thisMomGenoMat))
            thisMomHapMat <- replace(thisMomHapMat, is.na(recMat), NA)
            thisMomGenoMat <- replace(thisMomGenoMat, is.na(recMat), NA)
            lastRecMat <- recPosList[[b - 1]]
            thisMomGenoMat[posMat <= lastRecMat] <- FALSE#  zero out genotypes and haplotype identities before and past the recombination events missing
            thisMomHapMat[posMat <= lastRecMat] <- 0
            thisMomGenoMat[posMat > recMat] <- FALSE
            thisMomHapMat[posMat > recMat] <- 0
          }
          outMomGenoList[[b]] <- thisMomGenoMat  # save the genotypes
          outMomHapList[[b]] <- thisMomHapMat  # save the genotypes
          recPosList[[b]] <- recMat              # save the locations of recombinations

          newChrPicker <- rep(1,length(momChrPicker))   # iterate the chromosome picker
          if(sum(momChrPicker == 1) > 0) newChrPicker[which(momChrPicker == 1)] <- 2
          momChrPicker <- newChrPicker
        }
        offChromOnes <- outMomGenoList[[1]] + outMomGenoList[[2]]
        offHapOnes <- outMomHapList[[1]] + outMomHapList[[2]]

        #----------------------------
        # paternal meiosis
        #----------------------------
        if(chrLengs == 50)dadRecs <- sample(c(0,1),length(id),replace=TRUE)
        if(chrLengs == 100)dadRecs <- rep(1,length(id))
        dadRecLocsMat <- matrix(NA,nrow=length(id),ncol=max(dadRecs)+1)
        for(z in 1:ncol(dadRecLocsMat)){   # draw locations of crossovers for all individuals
          dadRecLocsMat[which(dadRecs >= z),z] <- runif(n=length(which(dadRecs >= z)),min=0,max=chrLengs)
          if(sum(dadRecs == (z-1)) > 0) dadRecLocsMat[which(dadRecs == (z-1)),z] <- chrLengs
        }
        if(sum(dadRecs > 1) > 0){          # sort locations of crossovers for all individuals
          moreThanOneRec <- which(dadRecs > 1)
          for(b in moreThanOneRec){
            dadRecLocsMat[b,1:(dadRecs[b]+1)] <- sort(dadRecLocsMat[b,])
          }
        }
        dadRecLocsMat[,ncol(dadRecLocsMat)] <- rep(chrLengs,nrow(dadRecLocsMat))
        dadChrPicker <- sample(x=c(1,2),size=length(id),replace=TRUE) # which parental chromosome copy to sample first
        outDadGenoList <- list() # store the maternal genotypes in segments between crossovers
        outDadHapList <- list()
        recPosList <- list() # store the positions of recombination revents

        for(b in 1:2){
          thisDadGenoMat <- matrix(NA,ncol=nChromLoci,nrow=length(id))
          thisDadHapMat <- matrix(NA,ncol=nChromLoci,nrow=length(id))
          if(sum(dadChrPicker == 1) > 0){
            thisDadGenoMat[which(dadChrPicker == 1),] <-  dadsCopy1[which(dadChrPicker == 1),]
            thisDadHapMat[which(dadChrPicker == 1),] <-  dadsHap1[which(dadChrPicker == 1),]
          }
          if(sum(dadChrPicker == 2) > 0){
            thisDadGenoMat[which(dadChrPicker == 2),] <-  dadsCopy2[which(dadChrPicker == 2),]
            thisDadHapMat[which(dadChrPicker == 2),] <-  dadsHap2[which(dadChrPicker == 2),]
          }
          if(b==1){
            recMat <- matrix(rep(dadRecLocsMat[,1],ncol(thisDadGenoMat)),nrow=nrow(dadRecLocsMat),ncol=ncol(thisDadGenoMat))
            recMat <- replace(recMat, is.na(recMat), chrLengs)
            thisDadGenoMat[posMat > recMat] <- FALSE   # make all snp genotypes and haplotype identities past the recombination events missing
            thisDadHapMat[posMat > recMat] <- 0
          }
          if(b==2){
            recMat <- matrix(rep(dadRecLocsMat[,b],ncol(thisDadGenoMat)),nrow=nrow(dadRecLocsMat),ncol=ncol(thisDadGenoMat))
            thisDadHapMat <- replace(thisDadHapMat, is.na(recMat), NA)
            thisDadGenoMat <- replace(thisDadGenoMat, is.na(recMat), NA)
            lastRecMat <- recPosList[[b - 1]]
            thisDadGenoMat[posMat <= lastRecMat] <- FALSE#  zero out genotypes and haplotype identities before and past the recombination events missing
            thisDadHapMat[posMat <= lastRecMat] <- 0
            thisDadGenoMat[posMat > recMat] <- FALSE
            thisDadHapMat[posMat > recMat] <- 0
          }
          outDadGenoList[[b]] <- thisDadGenoMat  # save the genotypes
          outDadHapList[[b]] <- thisDadHapMat  # save the genotypes
          recPosList[[b]] <- recMat              # save the locations of recombinations

          newChrPicker <- rep(1,length(dadChrPicker))   # iterate the chromosome picker
          if(sum(dadChrPicker == 1) > 0) newChrPicker[which(dadChrPicker == 1)] <- 2
          dadChrPicker <- newChrPicker
        }
        offChromTwos <- outDadGenoList[[1]] + outDadGenoList[[2]]
        offHapTwos <- outDadHapList[[1]] + outDadHapList[[2]]

        chr1List[[k]] <- as.matrix(offChromOnes)  # save the offspring genotypes
        chr2List[[k]] <- as.matrix(offChromTwos)
        hap1List[[k]] <- as.matrix(offHapOnes)
        hap2List[[k]] <- as.matrix(offHapTwos)
      }

      #################################################################################
      # save summary stats of genetic variation
      # and then remove genotypes for individuals that did not survive (for efficiency)
      #################################################################################
      aCnts1 <- NULL
      aCnts2 <- NULL
      hetMat <- NULL
      for(vb in 1:chrNum){
        aCnts1 <- c(aCnts1,colSums(chr1List[[vb]]))
        aCnts2 <- c(aCnts2,colSums(chr2List[[vb]]))
        hetMat <- cbind(hetMat,chr1List[[vb]] != chr2List[[vb]])
      }
      aCnts <- aCnts1 + aCnts2
      aFreqs <- aCnts /(2*nrow(chr1List[[1]]))
      obsHets <- colSums(hetMat)/nrow(hetMat)
      indHets <- c(indHets,rowSums(hetMat)/ncol(hetMat))
      expHet <- 2*aFreqs*(1-aFreqs)
      Fis <- 1-(obsHets/expHet)
      allFreqMat[i,] <- aFreqs
      if(i < gens){       # get rid of the genotypes and haplotype identities of non-surviving offspring
        for(vb in 1:chrNum){
          chr1List[[vb]] <- chr1List[[vb]][which(offAlive == 1),]
          chr2List[[vb]] <- chr2List[[vb]][which(offAlive == 1),]
          hap1List[[vb]] <- hap1List[[vb]][which(offAlive == 1),]
          hap2List[[vb]] <- hap2List[[vb]][which(offAlive == 1),]
        }
        idVec <- id[which(offAlive == 1)]
      }

    print(paste("done with generation ",i,sep=""))
    if(extinct == TRUE){print(paste("population extinct at generation ",i,sep=""))}
    i <- i + 1
  }
  if(getPedKinship == TRUE) pedObject <- cbind(pedObject,parPedKinship)

  ##########################################################
  # save the output genotypes
  ##########################################################
  genoMat1 <- NULL
  genoMat2 <- NULL
  for(i in 1:chrNum){
    genoMat1 <- rbind(genoMat1,chr1List[[i]])
    genoMat2 <- rbind(genoMat2,chr2List[[i]])
  }

  hapMat1 <- NULL
  hapMat2 <- NULL
  for(i in 1:chrNum){
    hapMat1 <- rbind(hapMat1,hap1List[[i]])
    hapMat2 <- rbind(hapMat2,hap2List[[i]])
  }
  #################################################
  # save individual heterozygosity
  #################################################
  het <- rep(NA,popSize)
  het <- c(het,indHets)
  pedObject <- pedObject[-which(is.na(pedObject[,1])),]
  pedObject <- cbind(pedObject,het)


  ############################################################################
  ############################################################################
  # add microsatellite genotypes
  ############################################################################
  ############################################################################
  msatFreqs <- 1/numAlleles

  foundMsat1List <- list()
  foundMsat2List <-list()
  numFounders <- popSize
  for(i in 1:chrNum){
    # first chromosome copy
    chrGenos <- NULL
    for(j in 1:sum(lociMap == i)){
      chrGenos <- cbind(chrGenos,sample(1:numAlleles,size=numFounders,replace=TRUE,prob=rep(msatFreqs,numAlleles)))
    }
    foundMsat1List [[i]] <- chrGenos
    # second chromosome copy
    chrGenos <- NULL
    for(j in 1:sum(lociMap == i)){
      chrGenos <- cbind(chrGenos,sample(1:numAlleles,size=numFounders,replace=TRUE,prob=rep(msatFreqs,numAlleles)))
    }
    foundMsat2List [[i]] <- chrGenos
  }

  #---------------------------------------------------------------------------
  # get the microsat genotypes
  #---------------------------------------------------------------------------
  msat1Mat <- NULL   # store the genotypes at microsats
  msat2Mat <- NULL

    for(j in 1:chrNum){
      msatChrLocs <- lociMap[which(lociMap[,1] == j),2]
      chrHapDat1 <- hap1List[[j]]
      chrHapDat2 <- hap2List[[j]]

      msat1Out <- matrix(NA,nrow=nrow(chrHapDat1),ncol=length(msatChrLocs))
      msat2Out <- matrix(NA,nrow=nrow(chrHapDat2),ncol=length(msatChrLocs))
      found1Haps <- foundHap1List[[j]][,1]
      found2Haps <- foundHap2List[[j]][,1]

      for(i in 1:length(msatChrLocs)){
        hapIDs1 <- chrHapDat1[,i]
        hapIDs2 <- chrHapDat2[,i]
        genos1 <- rep(NA,length(hapIDs1))
        genos2 <- rep(NA,length(hapIDs2))
        if(sum(hapIDs1 %in% found1Haps) > 0) genos1 [which(hapIDs1 %in% found1Haps == TRUE)] <- foundMsat1List[[j]][match(hapIDs1[which(hapIDs1 %in% found1Haps == TRUE)], found1Haps),i]
        if(sum(hapIDs1 %in% found2Haps) > 0) genos1 [which(hapIDs1 %in% found2Haps == TRUE)] <- foundMsat2List[[j]][match(hapIDs1[which(hapIDs1 %in% found2Haps == TRUE)], found2Haps),i]

        if(sum(hapIDs2 %in% found1Haps) > 0) genos2 [which(hapIDs2 %in% found1Haps == TRUE)] <- foundMsat1List[[j]][match(hapIDs2[which(hapIDs2 %in% found1Haps == TRUE)], found1Haps),i]
        if(sum(hapIDs2 %in% found2Haps) > 0) genos2 [which(hapIDs2 %in% found2Haps == TRUE)] <- foundMsat2List[[j]][match(hapIDs2[which(hapIDs2 %in% found2Haps == TRUE)], found2Haps),i]
        msat1Out[,i] <- genos1
        msat2Out[,i] <- genos2
      }

    msat1Mat <- cbind(msat1Mat,msat1Out)
    msat2Mat <- cbind(msat2Mat,msat2Out)
    }

  msatHet <- rowSums(msat1Mat != msat2Mat)/ncol(msat1Mat)
  pedObject <- cbind(pedObject,c(rep(NA,nrow(pedObject)-length(msatHet)),msatHet))
  colnames(pedObject) <- c(colnames(pedObject)[1:14],"msatHet")
  ###################
  #### outputs
  ###################
  msat1Mat <<- msat1Mat
  msat2Mat <<- msat2Mat
  pedObject <<- pedObject
  hapMat1 <<- hapMat1
  hapMat2 <<- hapMat2
  genoMat1 <<- genoMat1
  genoMat2 <<- genoMat2
  allFreqMat <<- allFreqMat
  lociMap <<- lociMap
  print("**********simulation done**********")
}
