#' Stochastic simulation of population dynamics and stabilizing selection on a quantitative trait with mutation.
#' This function is identical to logQuant_mut, except here, hard selection can be made to begin when heritability reaches a particular desired value.
#' @param burnin Number of generations before introducing large-effect mutations. There will only be one large effect allele in the population at any time.
#' @param gens Number of generations to simulate.
#' @param genSize Genome size in bp (unlinked nucleotides)
#' @param phen0 The initial mean phenotype.
#' @param phenOpt A vector giving the optimum phentype each generation.
#' @param phenShift The size of the increase in the optimum phenotype relative to the mean phenotype in the generation before the onset of hard selection
#' @param c Standard deviation (width) of the fitness function.
#' @param mu The mutation rate per base pair needed to get to the desired h^2.
#' @param muOff The last generation of mutation.
#' @param minSize The minimum of the uniform distribution of allelic effects (a) on the phenotype.
#' @param maxSize The maximum of the uniform distribution of allelic effects (a) on the phenotype.
#' @param N The initial (and constant before hard selection) population size.
#' @param Ve The desired environmental variance in the phenotype.
#' @param numLgEff Number of large effect mutations to have segregating at all times (a new one will be
#'                 introduced the generation after the last one goes to fixation or is lost).
#' @param lgSize A vector of length = 2 giving the effects of the possible large effect mutations.
#' @param desiredH2 The heritability that will trigger the onset of hard selection and turning off mutation.
#' @param h2Diff The maximum differnce between desiredH2 and the observed heritability to trigger the onset of hard selection and turning off mutation.
#' @param highMajorFreq Indicator for whether the new major allele should be > 0.5 (set to TRUE) of < 0.5 (set to FALSE).
#' @param hardSelecGen Generation when you want hard selection and density-dependent population growth to start.
#'     This will be overridden if/when Va reaches desiredH2 as described above.
#' @param K Carrying capacity.
#' @param lambda Maximum fitness (i.e., lambda population growth rate at N -> 0).
#' @param f Average (Poisson distributed) number of offspring per mother.
#' @export
logQuant_mut_h2Dep <- function(burnin,gens,genSize,phen0,phenOpt,phenShift,c,mu,muOff,minSize,maxSize,N,Ve,
                         numLgEff,lgSize,desiredH2,h2Diff,highMajorFreq,hardSelecGen,K,lambda,f){
  if(length(phenOpt) < gens) stop("phenOpt must have length >= gens")
  phenMat <- matrix(NA,nrow=N,ncol=gens)                    # phenotype matrix
  phenMat[,1] <- rnorm(N,mean=phen0,sd=sqrt(Ve))
  addVec <- NULL               # vector to store the additive effect at each segregating QTL
  h2Vec <- rep(NA,gens)        # vector for the h2 each generation

  # specify the Gaussian fitness function
  fitFun <- function(phen,maxFit,fitPhen,fitSd){maxFit*exp(-(((phen-fitPhen)^2)/(2*fitSd^2)))}

  ####################################
  # initialize the genotype matrices
  ####################################
  genoMat1 <- NULL   # first haploid genome copy
  genoMat2 <- NULL   # second haploid genome copy

  #######################################
  # initialize objects to store
  # information from the simulation
  #######################################
  segLgEffVec <- rep(NA,gens)
  numSeg <- 0   # keep track of the number of segregating loci
  locusEffs <- NULL
  majorGenos1 <- rep(0,N)      # store the genotypes at a major locus (allowing only one at a time) in vectors
  majorGenos2 <- rep(0,N)
  genVar <- rep(NA,gens) # track the total genetic variance
  addVar <- rep(NA,gens) # track the additive genetic variance
  addVarFreq <- rep(NA,gens) # track the additive genetic variance
  phenVar <- rep(NA,gens) # track the phenotypic variance
  mutsEst <- mu*genSize*2*K*gens  # twice the expected number of mutations throughout the simulation
  Ne <- rep(NA,gens)              # record the effective population size
  freqMat <- matrix(NA,nrow=round(mutsEst + 0.5*mutsEst),ncol=3)  # the generation of each mutation, its name, and its phenotypic effect
  freqList <- list()
  freqList[[1]] <- NA
  locusIDs <- NULL
  locusIter <- 0 # iterate the locus names
  numSegLgEff <- 0  # number of currently segregating large-effect mutations
  NVec <- rep(NA,gens)   # keep track of population size through time
  NVec[1] <- N
  extinct <- FALSE    # indicator for extinction
  majorLoci <- NULL
  locusEffs <- NULL
  mutNumVec <- rep(NA,gens)
  numSegVec <- rep(NA,gens)
  i <- 2
  changeHardSelecGen <- FALSE      # indicator for whether hardSelecGen has been changed by the Va reaching the needed threshold
  majorLocusFreqs <- rep(NA,gens)
  reproMean <- rep(NA,gens)
  reproVar <- rep(NA,gens)
  fitMean<- rep(NA,gens)
  fitVar<- rep(NA,gens)
  parNum <- rep(NA,gens)
  while(extinct == FALSE & i <= gens){
    ######################################################
    # stabilizing selection on the phenothpye
    #####################################################
    if(i < hardSelecGen){
      fitness <- fitFun(phen=phenMat[,i-1],maxFit = 1,fitPhen=phenOpt[i],fitSd=c)
      NVec [i] <- N
    }

    #########################################################
    # survival to breeding after the onset of hard selection
    #########################################################
    if(i >= hardSelecGen){
      fitness <- fitFun(phen=phenMat[1:NVec[i-1],i-1],maxFit = lambda,fitPhen=phenOpt[i],fitSd=c) # deterministic total fitness of each individual
      expSize <-  NVec[i-1]*exp(log(mean(fitness))*(1-(NVec[i-1]/K)))               # discrete logistic expected size in the next generation
      if(expSize > NVec[i-1] & NVec[i-1] > K) expSize <- K                          # avoid runaway population growth
      meanSurv <- expSize/(NVec[i-1]*f)                                             # mean survival needed to get expSize on average this generation
      nSurvivors <- sum(runif(n=length(fitness),min=0,max=1) < meanSurv)            # number of survivors

      ##########################################
      # test for extinction
      ##########################################
      if(nSurvivors <= 1 | is.null(nSurvivors) | is.na(nSurvivors)){extinct <- TRUE}
      if(extinct == FALSE){
        survivors <- sample(1:length(fitness),nSurvivors,replace=FALSE,prob=fitness/max(fitness))
        NVec[i] <- rpois(1,nSurvivors*f)       # the number of surviving moms drives the population dynamics
        moms <- sample(survivors,size=NVec[i],replace=TRUE)
        dads <- rep(NA,length(moms))                              # choose dads without allowing selfing
        for(j in 1:length(moms)){
          dads[j] <- sample((1:NVec[i-1])[-moms[j]],1,replace=FALSE,prob=fitness[-moms[j]])
        }
        #-------------------------------------
        # calculate Ne for the last generation
        #-------------------------------------
        uniquePars <- 1:NVec[i-1]
        repro <- rep(NA,length(uniquePars))
        for(j in 1:length(repro)){
          repro [j] <-  sum(c(dads,moms) == uniquePars[j])
        }
        Ne[i-1] <- (4*NVec[i-1] - 2)/(2  + var(repro))
      }
    }
    fitVar[i] <- var(fitness,na.rm=TRUE)    # save the deterministic fitness variance
    fitMean[i] <- mean(fitness,na.rm=TRUE)

    if(extinct == FALSE){                                        # continue if the population is not extinct
      ########################################################
      # mating
      ########################################################
      if(i < hardSelecGen){
        moms <- sample(1:NVec[i-1],size=N,replace=TRUE,prob=fitness)
        dads <- rep(NA,length(moms))                              # choose dads without allowing selfing
        for(j in 1:length(moms)){
          dads[j] <- sample((1:NVec[i-1])[-moms[j]],1,replace=FALSE,prob=fitness[-moms[j]])
        }
        #-------------------------------------
        # calculate Ne for the last generation
        #-------------------------------------
        uniquePars <- 1:NVec[i-1]
        repro <- rep(NA,length(uniquePars))
        for(j in 1:length(repro)){
          repro [j] <-  sum(c(dads,moms) == uniquePars[j])
        }
        Ne[i-1] <- (4*NVec[i-1] - 2)/(2  + var(repro))
      }
      reproMean[i] <- mean(repro,na.rm=TRUE)
      reproVar[i] <- var(repro,na.rm=TRUE)
      parNum[i] <- length(uniquePars)
      ############################################
      # mendelian segregation (if there are any segregating loci)
      ############################################
      if(numSeg > 0){
        fstGenCopy <- matrix(sample(c(TRUE,FALSE),NVec[i]*ncol(genoMat1),replace=TRUE),nrow=NVec[i],ncol=ncol(genoMat1))    # designate the maternal gene copy
        secGenCopy <- matrix(sample(c(TRUE,FALSE),NVec[i]*ncol(genoMat1),replace=TRUE),nrow=NVec[i],ncol=ncol(genoMat1))    # designate the paternal gene copy

        newGenoMat1 <- matrix(NA,NVec[i],ncol(genoMat1))       # initialize matrices for the maternal and paternal gene copies
        newGenoMat2 <- matrix(NA,NVec[i],ncol(genoMat1))

        for (j in 1:ncol(genoMat1)) {
          # assign the maternal haploid genome in the offspring
          newGenoMat1[which(fstGenCopy[,j] == TRUE),j] <- genoMat1[moms[which(fstGenCopy[,j] == TRUE)],j]
          newGenoMat1[which(fstGenCopy[,j] == FALSE),j] <- genoMat2[moms[which(fstGenCopy[,j] == FALSE)],j]

          # assign the paternal haploid genome in the offspring
          newGenoMat2[which(secGenCopy[,j] == TRUE),j] <- genoMat1[dads[which(secGenCopy[,j] == TRUE)],j]
          newGenoMat2[which(secGenCopy[,j] == FALSE),j] <- genoMat2[dads[which(secGenCopy[,j] == FALSE)],j]
        }
        colnames(newGenoMat1) <- colnames(genoMat1)
        colnames(newGenoMat2) <- colnames(genoMat2)
        genoMat1 <- newGenoMat1            #replace the parental genotypes with the offspring genotypes
        genoMat2 <- newGenoMat2
      }

      ##########################################################
      # mutations
      ##########################################################
      ##### first test for the presence of a major locus in the population. Introduce one if there  isn't one already,
      if(is.null(locusEffs) == FALSE) numSegLgEff <- sum(locusEffs %in% lgSize)
      if(is.null(locusEffs)) numSegLgEff <- 0
      segLgEffVec[i] <- numSegLgEff
      numMuts <- rbinom(1,genSize*NVec[i]*2,mu)                                                             # number of minor mutations this generation
      mutNumVec [i] <- numMuts
      if(numLgEff > 0 & numSegLgEff < numLgEff & i >= burnin) numMuts <- numMuts + numLgEff - numSegLgEff    # extra mutation if no major locus is in the population
      if(i >= muOff) numMuts <- 0                                                                           # no mutations if mutation has been shut off
      mutDone <- 0                                                                                          # test for mutation this generation
      if(numMuts > 0) mutInds <- sample(1:NVec[i],size=numMuts,replace=TRUE)                                # determine which offspring the mutation(s) occur in
      if(numMuts > 0 & numSeg == 0){                                                                        # new mutations if there are none already in the population
        newLocusIDs <- (locusIter + 1):(locusIter + numMuts)                                                # name the new loci
        locusIDs <- newLocusIDs
        genoMat1 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        genoMat2 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        for(j in 1:ncol(genoMat1)){
          genoMat1[mutInds[j],j] <- TRUE
        }
        colnames(genoMat1) <- locusIDs
        colnames(genoMat2) <- locusIDs
        numSeg <- ncol(genoMat1)
        mutDone <- 1
        newLocusEffs <- runif(numSeg,min=minSize,max=maxSize)
        if(numLgEff > 0 & numSegLgEff < numLgEff & i >= burnin & i < hardSelecGen) newLocusEffs[(length(newLocusEffs) - (numLgEff - numSegLgEff) + 1): length(newLocusEffs)] <- sample(lgSize,1,replace=FALSE)    # introduce a major mutation if needed
        locusEffs <- newLocusEffs
      }
      if(numMuts > 0 & numSeg > 0 & mutDone == 0){                        # new mutation if there are  already some segregating
        newLocusIDs <- (max(as.numeric(colnames(genoMat1)))+1):(max(as.numeric(colnames(genoMat1))) + numMuts)
        #locusIDs <- c(as.numeric(colnames(genoMat1)),newLocusIDs)   # ids of loci with derived allele frequencies of > 0 in the population
        newMat1 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)      # initialize genotypes at new mutations
        newMat2 <- matrix(FALSE,nrow=NVec[i],ncol=numMuts)
        colnames(newMat1) <- newLocusIDs
        colnames(newMat2) <- newLocusIDs

        for(j in 1:ncol(newMat1)){                              # distribute the mutations among the offspring
          mutPar <- sample(c(1,2),size = 1, replace = FALSE)
          if(mutPar == 1) newMat1[mutInds[j],j] <- TRUE
          if(mutPar == 2) newMat2[mutInds[j],j] <- TRUE
        }
        genoMat1 <- cbind(genoMat1,newMat1)                     # add the new genotypes
        genoMat2 <- cbind(genoMat2,newMat2)
        locusIDs <- as.numeric(colnames(genoMat1))
        #colnames(genoMat1) <- locusIDs
        #colnames(genoMat2) <- locusIDs
        newLocusEffs <- runif(numMuts,min=minSize,max=maxSize)           # effect of the new mutations on the phenotype
        if(numLgEff > 0 & numSegLgEff < numLgEff & i >= burnin) newLocusEffs[(length(newLocusEffs) - (numLgEff - numSegLgEff) + 1): length(newLocusEffs)] <- lgSize    # introduce a major mutation if needed
        locusEffs <- c(locusEffs,newLocusEffs)
      }

      #####################################################################
      # remove any loci where the derived allele has frequency = 0
      #####################################################################
      allCnts <- colSums(genoMat1,na.rm=TRUE) + colSums(genoMat2,na.rm=TRUE)
      numSegLgEff <- sum(allCnts > 0 & locusEffs %in% lgSize)   # count the segregating major loci
      if(sum(allCnts == 0) > 0){
        locusIDs <- as.numeric(colnames(genoMat1))
        genoMat1 <- genoMat1[,-which(allCnts == 0)]
        genoMat2 <- genoMat2[,-which(allCnts == 0)]
        locusIDs <- locusIDs[-which(allCnts == 0)]
        if(sum(allCnts > 0) == 1){
          restartGenoMat1 <- NULL
          restartGenoMat2 <- NULL
          restartGenoMat1 <- cbind(restartGenoMat1,genoMat1)
          restartGenoMat2 <- cbind(restartGenoMat2,genoMat2)
          genoMat1 <- restartGenoMat1
          genoMat2 <- restartGenoMat2
          colnames(genoMat1) <- as.character(locusIDs)
          colnames(genoMat2) <- as.character(locusIDs)
        }
        if(is.null(ncol(genoMat1)) | ncol(genoMat1) == 0){
          outGen1 <- NULL
          outGen2 <- NULL
          outGen1 <- cbind(outGen1,genoMat1)
          outGen2 <- cbind(outGen2,genoMat2)
          genoMat1 <- outGen1
          genoMat2 <- outGen2
          locusIDs <- NULL
        }
      }
      if(is.null(ncol(genoMat1))  | ncol(genoMat1) == 0) numSeg <- 0   # record the number of segregating mutations
      if(ncol(genoMat1) >= 1) numSeg <- ncol(genoMat1)

      #######################################
      # save allele frequencies
      #######################################
      if(numMuts > 0 ){
        genLoci <- rep(i,numMuts)                        # record the generation when these alleles arose
        freqDone <- 0                                    # indicator for allele frequency storage
        if(sum(is.na(freqMat[,1])) == nrow(freqMat)){    # in case we have an empty frequency matrix at this point
          outFreqMat <- matrix(c(genLoci,1:numMuts,newLocusEffs),ncol=3,nrow=(length(genLoci)))
          freqMat[1:numMuts,1:3] <- outFreqMat
          freqVec <- as.numeric((colSums(genoMat1) + colSums(genoMat2))/(2*NVec[i]))
          freqList[[i]] <- cbind(1:numMuts,freqVec)
          freqDone <- 1
        }
        if(sum(is.na(freqMat[,1])) < nrow(freqMat) & freqDone == 0 & ncol(genoMat1) > 0){    # if there are already loci in the frequency matrix
          genLoci <- rep(i,numMuts)
          outFreqMat <- matrix(c(genLoci,newLocusIDs,newLocusEffs),nrow=length(genLoci),ncol=3)
          freqMat[newLocusIDs,1:3] <- outFreqMat
          freqVec <- as.numeric((colSums(genoMat1) + colSums(genoMat2))/(2*NVec[i]))
          freqList[[i]] <- cbind(as.numeric(colnames(genoMat1)),freqVec)
        }
      }
      if(numMuts == 0){    # in case there are no new mutations
        if(sum(is.na(freqMat[,1])) != nrow(freqMat) & ncol(genoMat1) >= 1){
          freqVec <- as.numeric((colSums(genoMat1) + colSums(genoMat2))/(2*NVec[i]))
          EoutFreqVec <- rep(NA,nrow(freqMat))
          EoutFreqVec[locusIDs] <- freqVec
          freqList[[i]] <- cbind(as.numeric(colnames(genoMat1)),freqVec)
        }
      }
      if(ncol(genoMat1)  > 0)  numSegVec [i] <- ncol(genoMat1)
      if(ncol(genoMat1) == 0) numSegVec [i] <- 0

      #-------------------------------------
      # get the locus effects from freqMat
      #-------------------------------------
      if(is.null(locusIDs) == FALSE) locusEffs <- freqMat[locusIDs,3]
      if(sum(freqMat[which(freqMat[,1] == i),3] == 3.5 ) >1)stop(">1MajorLocus")

      ######################################################################
      # assign the offspring phenotype
      ######################################################################
      if(is.null(locusIDs) == FALSE){
        if(length(locusEffs) == 1) phenEffMat <- matrix(rep(locusEffs,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
        if(length(locusEffs) > 1) phenEffMat <- matrix(rep(locusEffs,nrow(genoMat1)),nrow=nrow(genoMat1),ncol=ncol(genoMat1),byrow=TRUE)
        genVals <- rowSums(genoMat1*phenEffMat) + rowSums(genoMat2*phenEffMat)
        addVar[i] <- var(genVals)
      }
      if(is.null(locusIDs)){
        genVals <- rep(0,length(dads))
        addVar[i] <- 0
      }

      offPhen <- genVals + rnorm(NVec[i],mean=0,sd=sqrt(Ve))      # assign the phenotypes with genetic and environmental effects
      if(nrow(phenMat) < NVec[i]) phenMat <- rbind(phenMat,matrix(NA,nrow=NVec[i] - nrow(phenMat),ncol=ncol(phenMat)))
      phenMat[1:length(offPhen),i] <- offPhen

      #######################################################################################
      # switch to hard selection if the additive variance (Va) is now very near desiredH2
      #######################################################################################
      if(sum(freqMat[freqList[[i]][,1],3] == lgSize) > 0){
        currentMajorFreq <- freqList[[i]][which(freqMat[freqList[[i]][,1],3] == lgSize),2]
        majorLocusFreqs[i] <- currentMajorFreq
      }

      if(abs(var(genVals)/var(offPhen) - desiredH2) <= h2Diff & i >= burnin & changeHardSelecGen == FALSE){
        if(currentMajorFreq >= 0.5 & highMajorFreq == TRUE){        # when the major locus is supposed to have an allele frequency >= 0.5
          phenOpt <- c(phenOpt[1:i],rep(mean(offPhen) + phenShift,gens - i))
          hardSelecGen <- i+1  # start hard selection
          muOff <- i+1         # turn off mutation
          changeHardSelecGen <- TRUE  # indicate that you are switching to hard selection due to the Va being that desirted
        }

        if(currentMajorFreq <= 0.5 & highMajorFreq == FALSE){        # when the major locus is supposed to have an allele frequency <= 0.5
          phenOpt <- c(phenOpt[1:i],rep(mean(offPhen) + phenShift,gens - i))
          hardSelecGen <- i+1  # start hard selection
          muOff <- i+1         # turn off mutation
          changeHardSelecGen <- TRUE  # indicate that you are switching to hard selection due to the Va being that desirted
        }
      }

      #############################################
      # calculate the genetic variance and h^2
      #############################################
      genVar[i] <- var(genVals)
      phenVar[i] <- var(offPhen)
      print(paste("genetic variance = ",genVar[i],sep=""))
      print(paste("generation ",i,sep=""))
    }
    print(paste("population size = ",NVec[i],sep=""))
    print(paste("mean phenotype = ",mean(phenMat[,i],na.rm=TRUE)))
    if(extinct == TRUE) print(paste("population extinct at generation ",i,sep=""))
    i <- i + 1   # interate the generation
  }
  # organize allele frequencies
  outFreqs <- matrix(NA,nrow=min(which(is.na(freqMat[,1])))-1,ncol=length(freqList)+1)
  outFreqs[,1] <- 1:nrow(outFreqs)
  for(i in 2:length(freqList)){
    outFreqs[freqList[[i]][,1],i] <- freqList[[i]][,2]
  }
  majorLocusFreqs <<- majorLocusFreqs
  hardSelecGen <<- hardSelecGen
  numSegVec <<- numSegVec
  outFreqs[,1] <- 1:nrow(outFreqs)
  genVar   <<- genVar
  phenVar  <<- phenVar
  addVar   <<- addVar
  phenMat  <<- phenMat
  NVec     <<- NVec
  outFreqs <<- outFreqs
  freqMat  <<- freqMat
  Ne <<- Ne
  phenOpt <<- phenOpt
  reproMean <<- reproMean
  reproVar <<- reproVar
  fitMean <<- fitMean
  fitVar <<- fitVar
  parNum <<- parNum
}
