#' A function for deterministic evolution of a quantitative trait and population dynamics in a population
#'
#' A function for deterministic evolution of a quantitative trait and population dynamics in a population
#' @param N0 Initial population size
#' @param K Carrying capacity
#' @param t Number of generation (non-overlapping) to run
#' @param lambda Fitness of an individual with optimal phenotype in the absence of density dependence
#' @param nLoci Number of loci affecting the quantitative trait (homogeneous effect sizes)
#' @param phen_0 Mean phenotype in generation 1
#' @param phen_opt Optimum phenotype
#' @param fit_sd Standard deviation of the Gaussian fitness function
#' @param h2_0 starting heritability of the quantitative trait
#' @param Vp_0 Starting variance of the selected quantitative trait
#' @param p0 Starting frequency of the allele conferring a larger phenotype
#' @param pseudoN Number of individuals to simulation genotypes for (this is to account for LD and potentially non-normal phenotype distribution
#' @export


logQuantPseudoGenos <- function(N0,K,t,lambda,nLoci,phen_0,phen_opt,fit_sd,h2_0,Vp_0,p0,pseudoN){
  Ve <- Vp_0 - h2_0*Vp_0        # environmental variance
  vQTL <- (h2_0*Vp_0)/nLoci   # genetic variance attributed to each QTL
  a <- sqrt((vQTL/(2*p0*(1-p0))))  # allelic effect

  ##### calculate the fitness of each genotype
  modInt <- phen_0 - weighted.mean( c(0,a,2*a),c((1-p0)^2,2*p0*(1-p0),(p0)^2))*nLoci # control the mean phenotype in generation 1
  genVals <- c(0,a,2*a) #  genetic values for different one-locus genotypes
  vpVec <-  rep(NA,t)  # phenotypic variance
  h2Vec <-  rep(NA,t)  # heritability
  freqVec <- rep(NA,t+1) # frequency of beneficial the beneficial allele(s)
  NVec <-  rep(NA,t+1)  # population size
  phenVec <- rep(NA,t) # mean phenotype through time
  meanFit <- rep(NA,t) # instantaneous growth rate per-capita

  ###### fitGaus (below) is the gaussian function describing the relationship between phenotype and fitness.
  ###### maxFit is the maximum fitness; fitPhen is the phenotype value with maximum fitness.
  ###### distSd is the sd of the distribution (defines how quickly fitness declines
  ###### from maxFit in either direction from fitPhen). phen is the phenotype value(s) to be evaluated
  fitGaus <- function(phen,maxFit,fitPhen,fitSd){maxFit*exp(-(((phen-fitPhen)^2)/(2*fitSd^2)))}

  ###### phenPDF (below) is the probability density function for the phenotype in a particular generation.
  ###### phenMu is the mean phenotype
  ###### phenSd is the standard deviation of the phenotype
  ###### phen is the phenotype value(s) to be evaluated
  phenPDF <- function(phen,phenMu,phenSd){(1/(phenSd*sqrt(2*pi)))*exp(-((phen-phenMu)^2)/(2*(phenSd^2)))}

  ###### fitness function: this is the fitness model (fitGaus) times the phenotype distribution (phenPDF)
  fitFun <- function(phen,phenMu,phenSd,fitPhen,fitSd,maxFit){(1/(phenSd*sqrt(2*pi)))*maxFit*exp(-(((phen-fitPhen)^2)/(2*(fitSd^2)))-(((phen-phenMu)^2)/(2*(phenSd^2))))}

  #################################################
  # simulate the population
  #################################################

for(i in 1:t){
    if(nLoci > 1){
      if(i == 1) {
        NVec[i] <- N0
        geno1Mat <- matrix(sample(c(0,1),pseudoN*nLoci,replace=TRUE,prob=c(1-p0,p0)),nrow=nLoci,ncol=pseudoN)
        geno2Mat <- matrix(sample(c(0,1),pseudoN*nLoci,replace=TRUE,prob=c(1-p0,p0)),nrow=nLoci,ncol=pseudoN)
      }
      phens <-  modInt + colSums(geno1Mat + geno2Mat)*a + rnorm(n=ncol(geno1Mat),mean=0,sd=sqrt(Ve))   # individual phenotypes

      #### Get the phenotype mean and variance, and mean fitness this generation
      #genoFreqVec <- c((1-freqVec[i])^2,2*freqVec[i]*(1-freqVec[i]),freqVec[i]^2) # frequencies of genotypes A1A1, A1A2, A2A2
      vpVec [i] <- var(phens)   # total phenotypic variance this generation
      freqVec[i] <- mean((rowSums(geno1Mat) + rowSums(geno2Mat))/(2*pseudoN))
      freqs <- (rowSums(geno1Mat) + rowSums(geno2Mat))/(2*pseudoN)
      h2Vec [i] <- sum(2*freqs*(1-freqs)*a^2) / vpVec [i] # heritability this generation
      phenVec[i] <- mean(phens)
      fits <- fitGaus(phen=phens,maxFit = lambda,fitPhen=phen_opt,fitSd=fit_sd)   # fitness of each individual
      meanFit [i] <- mean(fits)    # mean individual fitness in the population

      ##########################################
      ##### mating to produce genotypes
      ##########################################
      moms <- sample(1:ncol(geno1Mat),pseudoN,replace=TRUE,prob=fits/max(fits))
      dads <- sample(1:ncol(geno1Mat),pseudoN,replace=TRUE,prob=fits/max(fits))
      moms1 <- geno1Mat[,moms]
      moms2 <- geno2Mat[,moms]
      dads1 <- geno1Mat[,dads]
      dads2 <- geno2Mat[,dads]

      off1 <- matrix(NA,ncol=ncol(moms1),nrow=nrow(moms1))
      off2 <- matrix(NA,ncol=ncol(moms2),nrow=nrow(moms2))
      for (j in 1:nrow(off1)){
        momCopy <- sample(c(1,2),ncol(off1),replace=TRUE)    # randomly sample maternal and paternal alleles
        dadCopy <- sample(c(1,2),ncol(off1),replace=TRUE)
        off1 [j,which(momCopy == 1)] <- moms1[j,which(momCopy == 1)]    # get the maternal gamete
        off1 [j,which(momCopy == 2)] <- moms2[j,which(momCopy == 2)]
        off2 [j,which(dadCopy == 1)] <- dads1[j,which(dadCopy == 1)]    # get the paternal gamete
        off2 [j,which(dadCopy == 2)] <- dads2[j,which(dadCopy == 2)]
      }

      #### advance the genotypes
      geno1Mat <- off1
      geno2Mat <- off2

      #### advance the population to the next generation
      NVec[i + 1] <- NVec[i]*exp(log(meanFit[i])*(1-(NVec[i]/K)))   # discrete logistic population growth
      print(i)
    }

  if(nLoci == 1){
    if(i == 1) {
      NVec[i] <- N0
      geno1Mat <- sample(c(0,1),pseudoN,replace=TRUE,prob=c(1-p0,p0))
      geno2Mat <- sample(c(0,1),pseudoN,replace=TRUE,prob=c(1-p0,p0))
    }
    phens <-  modInt + (geno1Mat + geno2Mat)*a + rnorm(n=length(geno1Mat),mean=0,sd=sqrt(Ve))   # individual phenotypes

    #### Get the phenotype mean and variance, and mean fitness this generation
    #genoFreqVec <- c((1-freqVec[i])^2,2*freqVec[i]*(1-freqVec[i]),freqVec[i]^2) # frequencies of genotypes A1A1, A1A2, A2A2
    vpVec [i] <- var(phens)   # total phenotypic variance this generation
    freqVec[i] <- mean((sum(geno1Mat) + sum(geno2Mat))/(2*pseudoN))
    freqs <- (sum(geno1Mat) + sum(geno2Mat))/(2*pseudoN)
    h2Vec [i] <- sum(2*freqs*(1-freqs)*a^2) / vpVec [i] # heritability this generation
    phenVec[i] <- mean(phens)
    fits <- fitGaus(phen=phens,maxFit = lambda,fitPhen=phen_opt,fitSd=fit_sd)   # fitness of each individual
    meanFit [i] <- mean(fits)    # mean individual fitness in the population

    ##########################################
    ##### mating to produce genotypes
    ##########################################
    moms <- sample(1:length(geno1Mat),pseudoN,replace=TRUE,prob=fits/max(fits))
    dads <- sample(1:length(geno1Mat),pseudoN,replace=TRUE,prob=fits/max(fits))
    moms1 <- geno1Mat[moms]
    moms2 <- geno2Mat[moms]
    dads1 <- geno1Mat[dads]
    dads2 <- geno2Mat[dads]

    off1 <- rep(NA,length(moms1))
    off2 <- rep(NA,length(moms2))
    momCopy <- sample(c(1,2),length(off1),replace=TRUE)    # randomly sample maternal and paternal alleles
    dadCopy <- sample(c(1,2),length(off1),replace=TRUE)
    off1 [which(momCopy == 1)] <- moms1[which(momCopy == 1)]    # get the maternal gamete
    off1 [which(momCopy == 2)] <- moms2[which(momCopy == 2)]
    off2 [which(dadCopy == 1)] <- dads1[which(dadCopy == 1)]    # get the paternal gamete
    off2 [which(dadCopy == 2)] <- dads2[which(dadCopy == 2)]

    #### advance the genotypes
    geno1Mat <- off1
    geno2Mat <- off2

    #### advance the population to the next generation
    NVec[i + 1] <- NVec[i]*exp(log(meanFit[i])*(1-(NVec[i]/K)))   # discrete logistic population growth
    print(i)
  }
 }
 NVec <<- NVec
 freqVec <<- freqVec
 meanFit <<- meanFit
 vpVec <<- vpVec
 h2Vec <<- h2Vec
 phenVec <<- phenVec
 vQTL <<- vQTL
 Ve <<- Ve
 a <<- a
}



